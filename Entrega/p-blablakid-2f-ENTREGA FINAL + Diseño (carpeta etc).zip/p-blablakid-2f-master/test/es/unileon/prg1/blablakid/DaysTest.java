package es.unileon.prg1.blablakid;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class DaysTest {

	private Days days;
	private Day day;
	private Time start;
	private Time end;
	private Ride ride;

	@Before
	public void setUp() throws Exception {
		days = new Days(3);
		day = days.get(1);
		start = new Time(22, 12);
		end = new Time(23, 15);
		ride = new Ride("s", "s", start, end);
	}

	@Test
	public void testSearchDayExist() throws DayException {
		Day day2 = days.search("MONDAY");
		assertEquals("MONDAY", day2.getName());
	}

	@Test
	public void testGetTotalRides() throws RideException, DayException {
		Ride ride2 = new Ride("y", "y", start, end);
		day.addRide(ride);
		assertEquals(1, days.getTotalRides());
		days.get(2).addRide(ride2);
		assertEquals(2, days.getTotalRides());
	}

	@Test
	public void testGetDay0() throws DayException {
		Day dayt = days.get(0);
		assertEquals("MONDAY", dayt.getName());
	}

	@Test
	public void testGetDay1() throws DayException {
		Day dayt = days.get(1);
		assertEquals("TUESDAY", dayt.getName());
	}

	@Test
	public void testGetDay2() throws DayException {
		Day dayt = days.get(2);
		assertEquals("WEDNESDAY", dayt.getName());
	}

	@Test
	public void testGetDay3() throws DayException {
		Day dayt = days.get(3);
		assertEquals("THURSDAY", dayt.getName());
	}

	@Test
	public void testGetDay4() throws DayException {
		Day dayt = days.get(4);
		assertEquals("FRIDAY", dayt.getName());
	}

	@Test(expected = DayException.class)
	public void testGetDayFailLess() throws DayException {
		Day dayt = days.get(-1);
	}

	@Test(expected = DayException.class)
	public void testGetDayFailMore() throws DayException {
		Day dayt = days.get(12);
	}

	@Test
	public void testSearchDay() throws DayException {
		Day dayFound = days.search("MONDAY");
		assertEquals("MONDAY", dayFound.getName());
		assertEquals(null, days.search("NOTFOUND"));
	}

	@Test
	public void testToString() throws RideException {
		assertEquals("", days.toString());
	}

}
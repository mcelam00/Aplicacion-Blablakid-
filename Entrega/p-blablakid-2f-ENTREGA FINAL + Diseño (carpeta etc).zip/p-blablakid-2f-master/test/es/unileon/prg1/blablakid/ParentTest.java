package es.unileon.prg1.blablakid;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class ParentTest {

	private Parent parent;
	private Parent parentInvalid;
	private Ride ride;
	private Time timeS;
	private Time timeE;
	private Kids sons;
	private Days days;

	@Before
	public void setUp() throws Exception {

		parent = new Parent("Pedro", 1);
		timeS = new Time(12, 30);
		timeE = new Time(14, 30);
		ride = new Ride("StartPoint", "EndPoint", timeS, timeE);
		sons = new Kids(1);
		parent.setSons(sons);
		days = new Days(2);

	}

	@Test(expected = ParentException.class)
	public void testCreateNumberName() throws ParentException, DayException {
		parentInvalid = new Parent("R2D2", 3);
	}

	@Test(expected = ParentException.class)
	public void testCreateNullName() throws ParentException, DayException {
		parentInvalid = new Parent("", 3);
	}

	@Test
	public void testSetSons() throws KidException {

		Kids sons = new Kids(3);
		sons.add(new Kid("Paco"));
		this.parent.setSons(sons);
		assertEquals("Paco", this.parent.getSonName(0));

	}

	@Test
	public void testGetName() {
		assertEquals("Pedro", parent.getName());
	}

	@Test
	public void testAddRide() throws RideException, DayException {
		parent.addRide(ride, "MONDAY");
		assertEquals(1, parent.getAssignedRides(0));
	}

	@Test
	public void testRemoveRide() throws RideException, DayException {

		parent.addRide(ride, "MONDAY");
		assertEquals(1, parent.getAssignedRides(0));
		parent.removeRide("StartPoint", "EndPoint", "MONDAY");
		assertEquals(0, parent.getAssignedRides(0));

	}

	@Test
	public void testSearchRide() throws RideException, DayException {

		assertNull(parent.searchRide("startPoint", "endPoint", 0));
		parent.addRide(ride, "MONDAY");
		assertNotNull(parent.searchRide("startPoint", "endPoint", 0));

	}

	@Test
	public void testRemoveKid() throws KidException {

		Kid kid = new Kid("Paco");
		sons.add(kid);
		assertFalse(parent.removeKid(kid));
		parent.setSons(sons);
		assertTrue(parent.removeKid(kid));
	}

	@Test
	public void testGetMaxRides() throws RideException, DayException {

		assertEquals(1, parent.getMaxRides(0));

	}

	@Test
	public void testGetNumberOfRides() {

		assertEquals(0, parent.getNumberOfRides());

	}

	@Test
	public void testGetRide() throws DayException, RideException {

		assertNull(parent.getRide(1, 0));
		parent.addRide(ride, "Tuesday");
		assertNotNull(parent.getRide(1, 0));

	}

	@Test
	public void testToString() throws KidException {

		Kid kid1 = new Kid("Castro");
		sons.add(kid1);
		parent.setSons(sons);
		assertEquals("\n" + "###### Pedro ######\n" + "Kids:\nCastro\n" + "Rides:\n", this.parent.toString());
	}

}
package es.unileon.prg1.blablakid;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class ActivityTest {

	private Activity activity;
	private Ride befRide;
	private Ride afRide;

	@Before
	public void setUp() throws Exception {
		activity = new Activity("Baloncesto", "Palomera", 0);

	}

	@Test
	public void testActivity() throws ActivityException {
		assertEquals("Baloncesto", this.activity.getName());
		assertEquals("Palomera", this.activity.getPlace());
		assertEquals(0, this.activity.getDayOrdinal());
		assertNull(this.activity.getStart());
		assertNull(this.activity.getEnd());
		assertEquals("MONDAY", this.activity.getDay().toString());
		assertNull(this.activity.getBefore());
		assertNull(this.activity.getAfter());
	}

	@Test(expected = ActivityException.class)
	public void testActivityWrongName() throws ActivityException {
		Activity frances = new Activity("@", "EOI", 0);

	}

	@Test(expected = ActivityException.class)
	public void testActivityEmptyName() throws ActivityException {
		Activity frances = new Activity("", "EOI", 0);

	}

	@Test(expected = ActivityException.class)
	public void testActivityWrongPlace() throws ActivityException {
		Activity frances = new Activity("Frances", "@", 0);

	}

	@Test(expected = ActivityException.class)
	public void testActivityEmptyPlace() throws ActivityException {
		Activity frances = new Activity("Frances", "", 0);

	}

	@Test(expected = ActivityException.class)
	public void testActivityWrongDayNegative() throws ActivityException {
		Activity frances = new Activity("Frances", "EOI", -1);

	}

	@Test(expected = ActivityException.class)
	public void testActivityWrongDay() throws ActivityException {
		Activity frances = new Activity("Frances", "EOI", 6);

	}

	@Test
	public void testSetTime() throws ActivityException, TimeException {
		Time startTime = new Time(19, 30);
		Time endTime = new Time(20, 30);
		this.activity.setTime(startTime, endTime);
		assertEquals(startTime, this.activity.getStart());
		assertEquals(endTime, this.activity.getEnd());
	}

	@Test(expected = TimeException.class)
	public void testSetTimeWrong() throws ActivityException, TimeException {
		Time startTime = new Time(19, 30);
		Time endTime = new Time(20, 30);
		this.activity.setTime(endTime, startTime);

	}

	@Test
	public void testGetName() throws ActivityException {
		assertEquals("Baloncesto", this.activity.getName());
	}

	@Test
	public void testGetPlace() throws ActivityException {
		assertEquals("Palomera", this.activity.getPlace());
	}

	@Test
	public void testGetStart() throws ActivityException, TimeException {
		Time start = new Time(19, 30);
		Time end = new Time(20, 30);
		this.activity.setTime(start, end);
		assertEquals(start, this.activity.getStart());
	}

	@Test
	public void testGetEnd() throws ActivityException, TimeException {
		Time start = new Time(19, 30);
		Time end = new Time(20, 30);
		this.activity.setTime(start, end);
		assertEquals(end, this.activity.getEnd());
	}

	@Test
	public void testGetDay() throws ActivityException {
		assertEquals(WeekDays.MONDAY, this.activity.getDay());
	}

	@Test
	public void testGetDayOrdinal() throws ActivityException {
		assertEquals(0, this.activity.getDayOrdinal());
	}

	@Test
	public void testAddRideBefore() throws ActivityException, TimeException, RideException {
		Time startRide = new Time(16, 30);
		Time endRide = new Time(17, 00);
		Ride before = new Ride("Casa", "Palomera", startRide, endRide);
		Time startAct = new Time(17, 00);
		Time endAct = new Time(19, 00);
		this.activity.setTime(startAct, endAct);
		this.activity.addRide(before);
		assertEquals("Casa > Palomera : 16:30/17:0\nNo ride after " + this.activity.getName() + " assigned\n",
				this.activity.checkStatus());
	}

	@Test
	public void testAddRideAfter() throws ActivityException, TimeException, RideException {
		Time startRide = new Time(19, 00);
		Time endRide = new Time(19, 30);
		Ride after = new Ride("Palomera", "Casa", startRide, endRide);
		Time startAct = new Time(17, 00);
		Time endAct = new Time(19, 00);
		this.activity.setTime(startAct, endAct);
		this.activity.addRide(after);
		assertEquals("No ride before Baloncesto assigned\nPalomera > Casa : 19:0/19:30\n", this.activity.checkStatus());
	}

	@Test(expected = ActivityException.class)
	public void testAddRideBeforeAdded() throws ActivityException, TimeException, RideException {
		Time startRide = new Time(16, 30);
		Time endRide = new Time(17, 00);
		Ride before = new Ride("Casa", "Palomera", startRide, endRide);
		Time startAct = new Time(17, 00);
		Time endAct = new Time(19, 00);
		this.activity.setTime(startAct, endAct);
		this.activity.addRide(before);
		this.activity.addRide(before);
	}

	@Test(expected = ActivityException.class)
	public void testAddRideAfterAdded() throws ActivityException, TimeException, RideException {
		Time startRide = new Time(19, 00);
		Time endRide = new Time(19, 30);
		Ride after = new Ride("Palomera", "Casa", startRide, endRide);
		Time startAct = new Time(17, 00);
		Time endAct = new Time(19, 00);
		this.activity.setTime(startAct, endAct);
		this.activity.addRide(after);
		this.activity.addRide(after);
	}

	@Test(expected = ActivityException.class)
	public void testAddRideWrongTime() throws ActivityException, TimeException, RideException {
		Time startRide = new Time(17, 30);
		Time endRide = new Time(18, 30);
		Ride after = new Ride("Palomera", "Casa", startRide, endRide);
		Time startAct = new Time(17, 00);
		Time endAct = new Time(19, 00);
		this.activity.setTime(startAct, endAct);
		this.activity.addRide(after);
	}

	@Test
	public void testAddRideBeforeWrgPlace() throws ActivityException, TimeException, RideException {
		Time startRide = new Time(16, 30);
		Time endRide = new Time(17, 00);
		Ride before = new Ride("Casa", "EOI", startRide, endRide);
		Time startAct = new Time(17, 00);
		Time endAct = new Time(19, 00);
		this.activity.setTime(startAct, endAct);
		this.activity.addRide(before);
		assertEquals("No ride before " + this.activity.getName() + " assigned\nNo ride after " + this.activity.getName()
				+ " assigned\n", this.activity.checkStatus());
	}

	@Test
	public void testAddRideAfterWrgPlace() throws ActivityException, TimeException, RideException {
		Time startRide = new Time(19, 00);
		Time endRide = new Time(19, 30);
		Ride after = new Ride("EOI", "Casa", startRide, endRide);
		Time startAct = new Time(17, 00);
		Time endAct = new Time(19, 00);
		this.activity.setTime(startAct, endAct);
		this.activity.addRide(after);
		assertEquals("No ride before " + this.activity.getName() + " assigned\nNo ride after " + this.activity.getName()
				+ " assigned\n", this.activity.checkStatus());
	}

	@Test
	public void testRemoveRideBefore() throws ActivityException, TimeException, RideException {

		Time startRide = new Time(16, 30);
		Time endRide = new Time(17, 00);
		Ride before = new Ride("Casa", "Palomera", startRide, endRide);
		Time startAct = new Time(17, 00);
		Time endAct = new Time(19, 00);
		this.activity.setTime(startAct, endAct);
		this.activity.addRide(before);

		this.activity.removeRide(before);
		assertNull(this.activity.getBefore());

	}

	@Test
	public void testRemoveRideAfter() throws ActivityException, TimeException, RideException {

		Time startRide = new Time(19, 00);
		Time endRide = new Time(19, 30);
		Ride after = new Ride("Palomera", "Casa", startRide, endRide);
		Time startAct = new Time(17, 00);
		Time endAct = new Time(19, 00);
		this.activity.setTime(startAct, endAct);
		this.activity.addRide(after);

		this.activity.removeRide(after);
		assertNull(this.activity.getAfter());

	}

	@Test
	public void testRemoveRideBeforeWrong() throws ActivityException, TimeException, RideException {

		Time startRide = new Time(16, 30);
		Time endRide = new Time(17, 00);
		Ride before = new Ride("Casa", "Palomera", startRide, endRide);
		Time startAct = new Time(17, 00);
		Time endAct = new Time(19, 00);
		this.activity.setTime(startAct, endAct);
		this.activity.addRide(before);

		Ride beforeWrong = new Ride("EOI", "Palomera", startRide, endRide);

		this.activity.removeRide(beforeWrong);
		assertNotNull(this.activity.getBefore());

	}

	@Test
	public void testRemoveRideAfterWrong() throws ActivityException, TimeException, RideException {

		Time startRide = new Time(19, 00);
		Time endRide = new Time(19, 30);
		Ride after = new Ride("Palomera", "Casa", startRide, endRide);
		Time startAct = new Time(17, 00);
		Time endAct = new Time(19, 00);
		this.activity.setTime(startAct, endAct);
		this.activity.addRide(after);

		Ride afterWrong = new Ride("Palomera", "Palomera", startRide, endRide);

		this.activity.removeRide(afterWrong);
		assertNotNull(this.activity.getAfter());

	}

	@Test
	public void testToString() throws ActivityException {
		assertEquals(
				"Baloncesto(Palomera - MONDAY): null > null\nNo ride before Baloncesto assigned\nNo ride after Baloncesto assigned\n",
				this.activity.toString());

	}

}

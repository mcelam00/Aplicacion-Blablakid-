package es.unileon.prg1.blablakid;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ KidTest.class, KidsTest.class, DayTest.class, DaysTest.class, RideTest.class, RidesTest.class,
		ParentTest.class, ParentsTest.class, TimeTest.class, ActivityTest.class, ActivitiesTest.class,
		BlablakidTest.class })
public class AllTests {

}

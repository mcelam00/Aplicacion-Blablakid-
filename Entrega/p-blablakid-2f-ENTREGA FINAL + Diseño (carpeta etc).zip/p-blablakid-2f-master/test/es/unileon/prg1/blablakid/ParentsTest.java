package es.unileon.prg1.blablakid;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class ParentsTest {

	private Parent parent;
	private Parents parents;

	@Before
	public void setUp() throws Exception {

		parents = new Parents(2);
		parent = new Parent("Pedro", 1);

	}

	@Test
	public void testAddParent() throws ParentException {

		assertNull(parents.get(0));
		parents.add(parent);
		assertNotNull(parents.get(0));

	}

	@Test(expected = ParentException.class)
	public void testAddSameParent() throws ParentException {

		parents.add(parent);
		parents.add(parent);

	}

	@Test(expected = ParentException.class)
	public void testAddNullParent() throws ParentException {

		parents.add(null);

	}

	@Test(expected = ParentException.class)
	public void testAddFullParent() throws ParentException, DayException {

		Parent parent1 = new Parent("Diego", 1);
		Parent parent2 = new Parent("Castellanos", 1);

		parents.add(parent);
		parents.add(parent1);
		parents.add(parent2);

	}

	@Test(expected = ParentException.class)
	public void testRemoveNullParent() throws ParentException {

		parents.remove(null);

	}

	@Test(expected = ParentException.class)
	public void testRemoveNoExistingParent() throws ParentException, DayException {

		Parent parentos = new Parent("Castro", 1);
		parents.remove(parentos);

	}

	@Test
	public void testRemoveParent() throws ParentException {

		assertNull(parents.get(0));
		parents.add(parent);
		assertNotNull(parents.get(0));
		parents.remove(parent);

	}

	@Test
	public void testSearchPosition() throws ParentException, DayException {

		parents.add(parent);
		assertEquals(0, parents.searchPosition("Pedro"));

		Parent parent1 = new Parent("Pocoyo", 1);
		parents.add(parent1);
		assertEquals(1, parents.searchPosition("Pocoyo"));

	}

	@Test(expected = ParentException.class)
	public void testGetFailure() throws ParentException {

		parents.get(-2);

	}

	@Test
	public void testGetSize() {

		assertEquals(parents.getSize(), 2);

	}

	@Test
	public void testGetNumberOfParents() {

		assertEquals(parents.getNumberOfParents(), 0);

	}

	@Test
	public void testToString() throws ParentException {

		Kids sons = new Kids(3);
		parent.setSons(sons);
		parents.add(parent);
		assertEquals("\n" + "###### Pedro ######\n" + "Kids:\n" + "Rides:\n" + "", this.parents.toString());

	}

}

package es.unileon.prg1.blablakid;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class KidsTest {
	private Kids kidos;
	private Kid kid;

	@Before
	public void setUp() throws Exception {
		kidos = new Kids(3);
		kid = new Kid("Pepe");
	}

	@Test
	public void testEx() throws KidException {
		Kids kidos = new Kids(4); // para que no de error
	}

	@Test
	public void testGetNumberOfKids() throws KidException {
		assertEquals(kidos.getNumberOfKids(), 0);
	}

	@Test
	public void testGeKid() throws KidException {
		kidos.add(kid);
		assertEquals(kidos.get(0), kid);
	}

	@Test
	public void testAddKid() throws KidException {
		kidos.add(kid);
		assertTrue(kidos.exist(kid));
	}

	@Test(expected = KidException.class)
	public void testAddSameKid() throws KidException {
		kidos.add(kid);
		kidos.add(kid);
	}

	@Test(expected = KidException.class)
	public void testAddNullKid() throws KidException {
		kidos.add(null);
	}

	@Test(expected = KidException.class)
	public void testAddKidWhenFull() throws KidException {
		Kid Kid2 = new Kid("Pepi");
		Kid Kid3 = new Kid("Pepa");
		Kid KidFull = new Kid("Full");

		kidos.add(kid);
		kidos.add(Kid2);
		kidos.add(Kid3);
		kidos.add(KidFull);
	}

	@Test(expected = KidException.class)
	public void testRemoveNoExistingKid() throws KidException {
		Kid kido = new Kid("Juan");
		kidos.remove(kido);
	}

	@Test(expected = KidException.class)
	public void testRemoveNullKid() throws KidException {
		kidos.remove(null);
	}

	@Test
	public void testRemoveKid() throws KidException {
		kidos.add(kid);
		kidos.remove(kid);
		assertNull(kidos.get(0));
	}

	@Test
	public void testSearch() throws KidException {
		kidos.add(kid);
		Kid found = kidos.search("Pepe");
		assertEquals(0, kid.compareTo(found));
	}

	@Test
	public void testsearchNotExistingKid() throws KidException {
		assertEquals(null, kidos.search("Juan"));
	}

	@Test
	public void testSearchPosition() throws KidException {
		kidos.add(kid);
		assertEquals(0, kidos.searchPosition("Pepe"));
	}

	@Test
	public void testSearchPositionNotExistingKid() throws KidException {
		assertEquals(-1, kidos.searchPosition("Juan"));

	}

	@Test
	public void testToString() throws KidException {
		kidos.add(kid);
		assertEquals(kidos.toString(), kid.toString() + "\n");

	}

}

package es.unileon.prg1.blablakid;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class DayTest {

	private Day day;
	private Time startTime;
	private Time endTime;

	@Before
	public void setUp() throws Exception {
		day = new Day(3, 3);
		startTime = new Time(22, 12);
		endTime = new Time(23, 15);
	}

	@Test(expected = DayException.class)
	public void testCreateDayFailMore() throws DayException {
		Day fail = new Day(15, 3);
	}

	@Test(expected = DayException.class)
	public void testCreateDayFailLess() throws DayException {
		Day fail2 = new Day(-15, 3);
	}

	@Test
	public void testCreateMonday() throws DayException {
		day = new Day(0, 3);
		assertEquals(0, day.getDay());
		assertEquals("MONDAY", day.getName());
	}

	@Test
	public void testCreateTuesday() throws DayException {
		day = new Day(1, 3);
		assertEquals(1, day.getDay());
		assertEquals("TUESDAY", day.getName());
	}

	@Test
	public void testCreateWednesday() throws DayException {
		day = new Day(2, 3);
		assertEquals(2, day.getDay());
		assertEquals("WEDNESDAY", day.getName());
	}

	@Test
	public void testCreateThursday() throws DayException {
		day = new Day(3, 3);
		assertEquals(3, day.getDay());
		assertEquals("THURSDAY", day.getName());
	}

	@Test
	public void testCreateFriday() throws DayException {
		day = new Day(4, 3);
		assertEquals(4, day.getDay());
		assertEquals("FRIDAY", day.getName());
	}

	@Test
	public void testCompareToEquals() throws DayException {
		Day day2 = new Day(3, 3);
		assertEquals(0, day.compareTo(day2));
		assertEquals(0, day.compareTo(3));
	}

	@Test
	public void testCompareToBigger() throws DayException {
		Day day2 = new Day(2, 3);
		assertEquals(1, day.compareTo(day2));
		assertEquals(1, day.compareTo(2));
	}

	@Test
	public void testCompareToLower() throws DayException {
		Day day2 = new Day(4, 3);
		assertEquals(-1, day.compareTo(day2));
		assertEquals(-1, day.compareTo(4));
	}

	@Test
	public void testEqualsToTrue() throws DayException {
		Day dayTrue = new Day(3, 3);
		assertTrue(day.equalsTo(dayTrue));
	}

	@Test
	public void testEqualsToFalse() throws DayException {
		Day dayfalse = new Day(0, 3);
		assertFalse(day.equalsTo(dayfalse));
	}

	@Test
	public void testTryAddRide() throws RideException {
		Ride ride = new Ride("s", "s", startTime, endTime);
		day.addRide(ride);
		assertEquals(1, day.getNumberOfRides());
	}

	@Test
	public void testTryRemoveRide() throws RideException {
		Ride ride = new Ride("s", "s", startTime, endTime);
		day.addRide(ride);
		assertEquals(1, day.getNumberOfRides());
		day.removeRide("s", "s");
		assertEquals(0, day.getNumberOfRides());
	}

	@Test
	public void testCheckSearchRide() throws RideException {
		Ride ride = new Ride("s", "s", startTime, endTime);
		day.addRide(ride);
		Ride rideFound = day.searchRide("s", "s");
		assertTrue(ride.equalsTo(rideFound));
	}

	@Test
	public void testCheckSearchNoExistingRide() throws RideException {
		assertNull(day.searchRide("no", "existe"));
	}

	@Test
	public void testCheckExist() throws RideException {
		Ride ride = new Ride("s", "s", startTime, endTime);
		day.addRide(ride);
		assertTrue(day.exist(ride));
	}

	@Test
	public void testGetMaxRides() throws RideException {
		assertEquals(3, day.getMaxRides());
	}

	@Test
	public void testCheckToString() throws RideException {
		assertEquals("", day.toString());
		Ride ride = new Ride("s", "s", startTime, endTime);
		day.addRide(ride);
		assertEquals("THURSDAY\ns > s : 22:12/23:15\n", day.toString());

	}

}
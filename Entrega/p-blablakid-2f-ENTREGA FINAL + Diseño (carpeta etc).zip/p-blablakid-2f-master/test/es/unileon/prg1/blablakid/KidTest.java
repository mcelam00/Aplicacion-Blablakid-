package es.unileon.prg1.blablakid;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class KidTest {

	private Kid kid;
	private Activity activity;
	private int day;
	private Activities activities;

	@Before
	public void setUp() throws Exception {
		kid = new Kid("Pepe");
		activities = new Activities();
		;
		day = 2;
		activity = new Activity("Basket", "A", day);
	}

	@Test(expected = KidException.class)
	public void testCreateKidWithNumber() throws KidException {
		;
		Kid name1 = new Kid("C3p0");
	}

	@Test(expected = KidException.class)
	public void testCreateKidWithoutName() throws KidException {
		;
		Kid name2 = new Kid("");
	}

	@Test
	public void testGetName() {
		assertEquals("Pepe", kid.getName());
	}

	@Test
	public void testGetActivities() throws ActivityException {
		kid.addActivity(activity);
		assertEquals(activity, this.kid.getActivity(0));
	}

	@Test
	public void testGetNumOfActivities() {
		assertEquals(0, kid.getNumOfActivities());
	}

	@Test
	public void testCompareToBigger() throws KidException {
		Kid kidBigger = new Kid("Pepito");
		assertTrue(kid.compareTo(kidBigger) < 0);
	}

	@Test
	public void testCompareToEqual() throws KidException {
		assertEquals(kid.compareTo(kid), 0);
	}

	@Test
	public void testCompareToSmaller() throws KidException {
		Kid kidSmaller = new Kid("Pep");
		assertTrue(kid.compareTo(kidSmaller) > 0);
	}

	@Test
	public void testCompareToBiggerString() throws KidException {
		assertTrue(kid.compareTo("Pepito") < 0);
	}

	@Test
	public void testCompareToEqualString() throws KidException {
		assertEquals(kid.compareTo("Pepe"), 0);
	}

	@Test
	public void testCompareToSmallerString() throws KidException {
		assertTrue(kid.compareTo("Pep") > 0);
	}

	@Test(expected = ActivityException.class)
	public void testAddNullActivity() throws ActivityException {
		kid.addActivity(null);
	}

	@Test(expected = ActivityException.class)
	public void testAddExistingActivity() throws ActivityException {
		kid.addActivity(activity);
		kid.addActivity(activity);
	}

	@Test(expected = ActivityException.class)
	public void testAddTooManyActivities() throws ActivityException {
		Activity activity1 = new Activity("Basket", "A", day);
		Activity activity2 = new Activity("Baske", "B", day);
		Activity activityfull = new Activity("Bask", "C", day);
		kid.addActivity(activity);
		kid.addActivity(activity1);
		kid.addActivity(activity2);
		kid.addActivity(activityfull);
	}

	@Test
	public void testAddActivity() throws ActivityException {
		kid.addActivity(activity);
		assertEquals(kid.getNumOfActivities(), 1);
	}

	@Test(expected = ActivityException.class)
	public void testRemoveNotExistingActivity() throws ActivityException {
		kid.removeActivity("Futbol", day);
	}

	@Test
	public void testRemoveActivity() throws ActivityException {
		kid.addActivity(activity);
		kid.removeActivity("Basket", day);
		assertEquals(kid.getNumOfActivities(), 0);
	}

	@Test
	public void testAddRide() throws ActivityException, RideException, TimeException {
		String startPoint = "place1";
		String endPoint = "A";
		Time startTimeA = new Time(19, 0);
		Time endTimeA = new Time(19, 30);
		Time startTimeR = new Time(18, 30);
		Time endTimeR = new Time(19, 0);
		activity.setTime(startTimeA, endTimeA);
		Ride ride = new Ride(startPoint, endPoint, startTimeR, endTimeR);
		kid.addActivity(activity);
		assertTrue(kid.addRide(ride, activity.getName(), day));
	}

	@Test
	public void testRemoveRide() throws ActivityException, RideException, TimeException {
		String startPoint = "place1";
		String endPoint = "A";
		Time startTimeA = new Time(19, 0);
		Time endTimeA = new Time(19, 30);
		Time startTimeR = new Time(18, 30);
		Time endTimeR = new Time(19, 0);
		activity.setTime(startTimeA, endTimeA);
		Ride ride = new Ride(startPoint, endPoint, startTimeR, endTimeR);
		kid.addActivity(activity);
		kid.addRide(ride, activity.getName(), day);
		kid.removeRide(ride);
		assertNull(kid.getActivity(0).getAfter());
		assertNull(kid.getActivity(0).getBefore());
	}

	@Test
	public void testToString() {
		assertEquals("****** Pepe ******\n" + this.activities.toString(), kid.toString());
	}
}
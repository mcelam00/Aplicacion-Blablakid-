package es.unileon.prg1.blablakid;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class RidesTest {

	private Rides rides;
	private Ride ride;
	private Time timeS;
	private Time timeE;

	@Before
	public void setUp() throws Exception {
		timeS = new Time(12, 30);
		timeE = new Time(14, 30);
		ride = new Ride("StartPoint", "EndPoint", timeS, timeE);
		rides = new Rides(1);
	}

	@Test
	public void testAddRide() throws RideException {
		rides.add(ride);
		assertEquals(true, rides.exist(ride));
		assertEquals(1, rides.getNumberOfRides());
	}

	@Test(expected = RideException.class)
	public void testAddSameRide() throws RideException {
		rides.add(ride);
		rides.add(ride);
	}

	@Test(expected = RideException.class)
	public void testAddNullRide() throws RideException {
		rides.add(null);
	}

	@Test(expected = RideException.class)
	public void testAddRideWhenFull() throws RideException {
		Ride ride2 = new Ride("aafa", "b", timeS, timeE);
		Ride ride3 = new Ride("a", "baf", timeS, timeE);
		Ride ride4 = new Ride("aaf", "b", timeS, timeE);
		Ride ride5 = new Ride("a", "ba", timeS, timeE);
		Ride ride6 = new Ride("aa", "b", timeS, timeE);
		Ride rideFull = new Ride("Full", "Full", timeS, timeE);

		rides.add(ride);
		rides.add(ride2);
		rides.add(ride3);
		rides.add(ride4);
		rides.add(ride5);
		rides.add(ride6);
		rides.add(rideFull);
	}

	@Test(expected = RideException.class)
	public void testRemoveNoExistingRide() throws RideException {
		Ride rideno = new Ride("a", "b", timeS, timeE);
		rides.remove(rideno);
	}

	@Test(expected = RideException.class)
	public void testRemoveNullRide() throws RideException {
		rides.remove(null);
	}

	@Test
	public void testSearch() throws RideException {
		rides.add(ride);
		Ride found = rides.search("StartPoint", "EndPoint");
		assertEquals(true, ride.equalsTo(found));
	}

	@Test
	public void testSearchNoExistingRide() throws RideException {
		assertNull(rides.search("A", "b"));
	}

	@Test
	public void testToString() throws RideException {
		rides.add(ride);
		assertEquals("StartPoint > EndPoint : 12:30/14:30\n", rides.toString());
	}
}

package es.unileon.prg1.blablakid;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class BlablakidTest {

	private Blablakid blablakid;

	@Before
	public void setUp() throws Exception {
		int numKids = 3;
		blablakid = new Blablakid(numKids);

	}

	@Test(expected = KidException.class)
	public void testAddFail() throws BlablakidException, KidException {
		Kid kid = null;
		this.blablakid.add(kid);
	}

	@Test
	public void testAdd() throws BlablakidException, KidException {
		Kid kid = new Kid("Daniel");
		this.blablakid.add(kid);

	}

	@Test(expected = BlablakidException.class)
	public void testRemoveKidNotExist()
			throws KidException, ParentException, DayException, RideException, BlablakidException {
		this.blablakid.removeKid("Daniel");

	}

	@Test
	public void testRemoveKid() throws KidException, ParentException, DayException, RideException, BlablakidException {
		Kid kid = new Kid("Daniel");
		this.blablakid.add(kid);
		this.blablakid.removeKid("Daniel");

	}

	@Test
	public void testRemoveKidActivity()
			throws KidException, ParentException, DayException, RideException, BlablakidException, ActivityException {
		Kid kid = new Kid("Daniel");
		this.blablakid.add(kid);
		Activity baloncesto = new Activity("Baloncesto", "Palomera", 0);
		this.blablakid.addActivity(baloncesto, "Daniel");
		this.blablakid.removeKid("Daniel");

	}

	@Test
	public void testRemoveKidRideAfter() throws KidException, ParentException, DayException, RideException,
			BlablakidException, ActivityException, TimeException {
		Kid kid = new Kid("Daniel");
		this.blablakid.add(kid);
		Parent parent = new Parent("Eva", 2);
		Kids fakeKids = new Kids(2);
		fakeKids.add(kid);
		this.blablakid.addParent(parent, fakeKids);
		Activity baloncesto = new Activity("Baloncesto", "Palomera", 2);
		Time startA = new Time(17, 00);
		Time endA = new Time(19, 00);
		baloncesto.setTime(startA, endA);
		this.blablakid.addActivity(baloncesto, "Daniel");
		Time start = new Time(19, 00);
		Time end = new Time(19, 30);
		Ride ride = new Ride("Palomera", "Casa", start, end);
		this.blablakid.addRide(ride, "Eva", "Baloncesto", "Daniel", 2);
		this.blablakid.removeKid("Daniel");
	}

	@Test
	public void testRemoveKidRideBefore() throws KidException, ParentException, DayException, RideException,
			BlablakidException, ActivityException, TimeException {
		Kid kid = new Kid("Daniel");
		this.blablakid.add(kid);
		Parent parent = new Parent("Eva", 2);
		Kids fakeKids = new Kids(2);
		fakeKids.add(kid);
		this.blablakid.addParent(parent, fakeKids);
		Activity baloncesto = new Activity("Baloncesto", "Palomera", 2);
		Time startA = new Time(17, 00);
		Time endA = new Time(19, 00);
		baloncesto.setTime(startA, endA);
		this.blablakid.addActivity(baloncesto, "Daniel");
		Time start = new Time(16, 30);
		Time end = new Time(17, 00);
		Ride ride = new Ride("Casa", "Palomera", start, end);
		this.blablakid.addRide(ride, "Eva", "Baloncesto", "Daniel", 2);
		this.blablakid.removeKid("Daniel");
	}

	@Test(expected = BlablakidException.class)
	public void testAddParentWithoutExistingKid() throws KidException, ParentException, DayException, RideException,
			BlablakidException, ActivityException, TimeException {
		Kid kid = new Kid("Daniel");
		Parent parent = new Parent("Eva", 2);
		Kids fakeKids = new Kids(2);
		fakeKids.add(kid);
		this.blablakid.addParent(parent, fakeKids);
	}

	@Test
	public void testRemoveParent() throws KidException, ParentException, DayException, RideException,
			BlablakidException, ActivityException, TimeException {
		Kid kid = new Kid("Daniel");
		this.blablakid.add(kid);
		Parent parent = new Parent("Eva", 2);
		Kids fakeKids = new Kids(2);
		fakeKids.add(kid);
		this.blablakid.addParent(parent, fakeKids);
		this.blablakid.removeParent("Eva");
	}

	@Test(expected = BlablakidException.class)
	public void testRemoveNotExistParent() throws KidException, ParentException, DayException, RideException,
			BlablakidException, ActivityException, TimeException {
		this.blablakid.removeParent("Eva");
	}

	@Test
	public void testRemoveParentwithRide() throws KidException, ParentException, DayException, RideException,
			BlablakidException, ActivityException, TimeException {
		Kid kid = new Kid("Daniel");
		this.blablakid.add(kid);
		Parent parent = new Parent("Eva", 2);
		Kids fakeKids = new Kids(2);
		fakeKids.add(kid);
		this.blablakid.addParent(parent, fakeKids);
		Activity baloncesto = new Activity("Baloncesto", "Palomera", 2);
		Time startA = new Time(17, 00);
		Time endA = new Time(19, 00);
		baloncesto.setTime(startA, endA);
		this.blablakid.addActivity(baloncesto, "Daniel");
		Time start = new Time(16, 30);
		Time end = new Time(17, 00);
		Ride ride = new Ride("Casa", "Palomera", start, end);
		this.blablakid.addRide(ride, "Eva", "Baloncesto", "Daniel", 2);
		this.blablakid.removeParent("Eva");
	}

	@Test(expected = BlablakidException.class)
	public void testAddActivityToANotExistKid() throws KidException, ParentException, DayException, RideException,
			BlablakidException, ActivityException, TimeException {
		Activity baloncesto = new Activity("Baloncesto", "Palomera", 2);
		Time startA = new Time(17, 00);
		Time endA = new Time(19, 00);
		baloncesto.setTime(startA, endA);
		this.blablakid.addActivity(baloncesto, "Daniel");
	}

	@Test
	public void testRemoveActivityWithAfter() throws KidException, ParentException, DayException, RideException,
			BlablakidException, ActivityException, TimeException {
		Kid kid = new Kid("Daniel");
		this.blablakid.add(kid);
		Parent parent = new Parent("Eva", 2);
		Kids fakeKids = new Kids(2);
		fakeKids.add(kid);
		this.blablakid.addParent(parent, fakeKids);
		Activity baloncesto = new Activity("Baloncesto", "Palomera", 2);
		Time startA = new Time(17, 00);
		Time endA = new Time(19, 00);
		baloncesto.setTime(startA, endA);
		this.blablakid.addActivity(baloncesto, "Daniel");
		Time start = new Time(16, 30);
		Time end = new Time(17, 00);
		Ride ride = new Ride("Casa", "Palomera", start, end);
		this.blablakid.addRide(ride, "Eva", "Baloncesto", "Daniel", 2);
		this.blablakid.removeActivity("Baloncesto", 2, "Daniel");
	}

	@Test
	public void testRemoveActivityWithBefore() throws KidException, ParentException, DayException, RideException,
			BlablakidException, ActivityException, TimeException {
		Kid kid = new Kid("Daniel");
		this.blablakid.add(kid);
		Parent parent = new Parent("Eva", 2);
		Kids fakeKids = new Kids(2);
		fakeKids.add(kid);
		this.blablakid.addParent(parent, fakeKids);
		Activity baloncesto = new Activity("Baloncesto", "Palomera", 2);
		Time startA = new Time(17, 00);
		Time endA = new Time(19, 00);
		baloncesto.setTime(startA, endA);
		this.blablakid.addActivity(baloncesto, "Daniel");
		Time start = new Time(19, 00);
		Time end = new Time(19, 30);
		Ride ride = new Ride("Palomera", "Casa", start, end);
		this.blablakid.addRide(ride, "Eva", "Baloncesto", "Daniel", 2);
		this.blablakid.removeActivity("Baloncesto", 2, "Daniel");
	}

	@Test(expected = BlablakidException.class)
	public void testRemoveActivityKidNotExist() throws KidException, ParentException, DayException, RideException,
			BlablakidException, ActivityException, TimeException {
		Kid kid = new Kid("Daniel");
		this.blablakid.add(kid);
		Parent parent = new Parent("Eva", 2);
		Kids fakeKids = new Kids(2);
		fakeKids.add(kid);
		this.blablakid.addParent(parent, fakeKids);
		Activity baloncesto = new Activity("Baloncesto", "Palomera", 2);
		Time startA = new Time(17, 00);
		Time endA = new Time(19, 00);
		baloncesto.setTime(startA, endA);
		this.blablakid.addActivity(baloncesto, "Daniel");
		this.blablakid.removeActivity("Baloncesto", 2, "Beatriz");
	}

	@Test(expected = KidException.class)
	public void testAddRideNotExistKid() throws KidException, ParentException, DayException, RideException,
			BlablakidException, ActivityException, TimeException {
		Kid kid = new Kid("Daniel");
		this.blablakid.add(kid);
		Parent parent = new Parent("Eva", 2);
		Kids fakeKids = new Kids(2);
		fakeKids.add(kid);
		this.blablakid.addParent(parent, fakeKids);
		Activity baloncesto = new Activity("Baloncesto", "Palomera", 2);
		Time startA = new Time(17, 00);
		Time endA = new Time(19, 00);
		baloncesto.setTime(startA, endA);
		this.blablakid.addActivity(baloncesto, "Daniel");
		Time start = new Time(19, 00);
		Time end = new Time(19, 30);
		Ride ride = new Ride("Palomera", "Casa", start, end);
		this.blablakid.addRide(ride, "Eva", "Baloncesto", "Beatriz", 2);
	}

	@Test(expected = KidException.class)
	public void testAddRideNotExistParent() throws KidException, ParentException, DayException, RideException,
			BlablakidException, ActivityException, TimeException {
		Kid kid = new Kid("Daniel");
		this.blablakid.add(kid);
		Activity baloncesto = new Activity("Baloncesto", "Palomera", 2);
		Time startA = new Time(17, 00);
		Time endA = new Time(19, 00);
		baloncesto.setTime(startA, endA);
		this.blablakid.addActivity(baloncesto, "Daniel");
		Time start = new Time(19, 00);
		Time end = new Time(19, 30);
		Ride ride = new Ride("Palomera", "Casa", start, end);
		this.blablakid.addRide(ride, "Eva", "Baloncesto", "Daniel", 2);
	}

	@Test(expected = BlablakidException.class)
	public void testAddRideOverMaxRides() throws KidException, ParentException, DayException, RideException,
			BlablakidException, ActivityException, TimeException {
		Kid kid = new Kid("Daniel");
		this.blablakid.add(kid);
		Parent parent = new Parent("Eva", 1);
		Kids fakeKids = new Kids(2);
		fakeKids.add(kid);
		this.blablakid.addParent(parent, fakeKids);
		Activity baloncesto = new Activity("Baloncesto", "Palomera", 2);
		Time startA = new Time(17, 00);
		Time endA = new Time(19, 00);
		baloncesto.setTime(startA, endA);
		this.blablakid.addActivity(baloncesto, "Daniel");
		Time start = new Time(19, 00);
		Time end = new Time(19, 30);
		Ride ride = new Ride("Palomera", "Casa", start, end);
		this.blablakid.addRide(ride, "Eva", "Baloncesto", "Daniel", 2);
		Time start2 = new Time(16, 30);
		Time end2 = new Time(17, 00);
		Ride ride2 = new Ride("Casa", "Palomera", start2, end2);
		this.blablakid.addRide(ride2, "Eva", "Baloncesto", "Daniel", 2);
	}

	@Test(expected = BlablakidException.class)
	public void testAddRideNotMatchActivity() throws KidException, ParentException, DayException, RideException,
			BlablakidException, ActivityException, TimeException {
		Kid kid = new Kid("Daniel");
		this.blablakid.add(kid);
		Parent parent = new Parent("Eva", 1);
		Kids fakeKids = new Kids(2);
		fakeKids.add(kid);
		this.blablakid.addParent(parent, fakeKids);
		Activity baloncesto = new Activity("Baloncesto", "Palomera", 2);
		Time startA = new Time(17, 00);
		Time endA = new Time(19, 00);
		baloncesto.setTime(startA, endA);
		this.blablakid.addActivity(baloncesto, "Daniel");
		Time start = new Time(19, 00);
		Time end = new Time(19, 30);
		Ride ride = new Ride("Playa", "Casa", start, end);
		this.blablakid.addRide(ride, "Eva", "Baloncesto", "Daniel", 2);
	}

	@Test
	public void testRemoveRide() throws KidException, ParentException, DayException, RideException, BlablakidException,
			ActivityException, TimeException {
		Kid kid = new Kid("Daniel");
		this.blablakid.add(kid);
		Parent parent = new Parent("Eva", 1);
		Kids fakeKids = new Kids(2);
		fakeKids.add(kid);
		this.blablakid.addParent(parent, fakeKids);
		Activity baloncesto = new Activity("Baloncesto", "Palomera", 2);
		Time startA = new Time(17, 00);
		Time endA = new Time(19, 00);
		baloncesto.setTime(startA, endA);
		this.blablakid.addActivity(baloncesto, "Daniel");
		Time start = new Time(19, 00);
		Time end = new Time(19, 30);
		Ride ride = new Ride("Palomera", "Casa", start, end);
		this.blablakid.addRide(ride, "Eva", "Baloncesto", "Daniel", 2);
		this.blablakid.removeRide("Eva", 2, "Palomera", "Casa");
	}

	@Test(expected = ParentException.class)
	public void testRemoveRideNotParentExist() throws KidException, ParentException, DayException, RideException,
			BlablakidException, ActivityException, TimeException {
		Kid kid = new Kid("Daniel");
		this.blablakid.add(kid);
		Parent parent = new Parent("Eva", 1);
		Kids fakeKids = new Kids(2);
		fakeKids.add(kid);
		this.blablakid.addParent(parent, fakeKids);
		Activity baloncesto = new Activity("Baloncesto", "Palomera", 2);
		Time startA = new Time(17, 00);
		Time endA = new Time(19, 00);
		baloncesto.setTime(startA, endA);
		this.blablakid.addActivity(baloncesto, "Daniel");
		Time start = new Time(19, 00);
		Time end = new Time(19, 30);
		Ride ride = new Ride("Palomera", "Casa", start, end);
		this.blablakid.addRide(ride, "Eva", "Baloncesto", "Daniel", 2);
		this.blablakid.removeRide("Pedro", 2, "Palomera", "Casa");
	}

	@Test
	public void testShowSummary() throws KidException, ParentException, DayException, RideException, BlablakidException,
			ActivityException, TimeException {
		Kid kid = new Kid("Daniel");
		this.blablakid.add(kid);
		Parent parent = new Parent("Eva", 1);
		Kids fakeKids = new Kids(2);
		fakeKids.add(kid);

		this.blablakid.addParent(parent, fakeKids);
		Activity baloncesto = new Activity("Baloncesto", "Palomera", 2);
		Time startA = new Time(17, 00);
		Time endA = new Time(19, 00);
		baloncesto.setTime(startA, endA);
		this.blablakid.addActivity(baloncesto, "Daniel");
		Time start = new Time(19, 00);
		Time end = new Time(19, 30);
		Ride ride = new Ride("Palomera", "Casa", start, end);
		this.blablakid.addRide(ride, "Eva", "Baloncesto", "Daniel", 2);
		assertEquals(this.blablakid.showSummary(),
				"///////////////////////\n" + "\n" + "KIDS:\n" + "\n" + "****** Daniel ******\n"
						+ "Baloncesto(Palomera - WEDNESDAY): 17:0 > 19:0\n" + "No ride before Baloncesto assigned\n"
						+ "Palomera > Casa : 19:0/19:30\n" + "\n" + "PARENTS:\n" + "\n" + "###### Eva ######\n"
						+ "Kids:\n" + "Daniel\n" + "Rides:\n" + "WEDNESDAY\n" + "Palomera > Casa : 19:0/19:30\n" + "\n"
						+ "///////////////////////");
	}

	@Test
	public void checkStatus() throws KidException, ParentException, DayException, RideException, BlablakidException,
			ActivityException, TimeException {
		Kid kid = new Kid("Daniel");
		this.blablakid.add(kid);
		Parent parent = new Parent("Eva", 1);
		Kids fakeKids = new Kids(2);
		fakeKids.add(kid);
		this.blablakid.addParent(parent, fakeKids);
		Activity baloncesto = new Activity("Baloncesto", "Palomera", 2);
		Time startA = new Time(17, 00);
		Time endA = new Time(19, 00);
		baloncesto.setTime(startA, endA);
		this.blablakid.addActivity(baloncesto, "Daniel");
		Time start = new Time(19, 00);
		Time end = new Time(19, 30);
		Ride ride = new Ride("Palomera", "Casa", start, end);
		this.blablakid.addRide(ride, "Eva", "Baloncesto", "Daniel", 2);
		assertEquals(this.blablakid.checkStatus(),
				"No ride before Baloncesto assigned\n" + "Palomera > Casa : 19:0/19:30\n");
	}

	@Test
	public void checkStatusWithoutActivities() throws KidException, ParentException, DayException, RideException,
			BlablakidException, ActivityException, TimeException {
		Kid kid = new Kid("Daniel");
		this.blablakid.add(kid);
		assertEquals(this.blablakid.checkStatus(), "Kids have not activities without rides");
	}

	@Test(expected = BlablakidException.class)
	public void checkStatusWithoutKids() throws KidException, ParentException, DayException, RideException,
			BlablakidException, ActivityException, TimeException {
		assertEquals(this.blablakid.checkStatus(), "");
	}

}

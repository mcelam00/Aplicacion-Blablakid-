package es.unileon.prg1.blablakid;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class ActivitiesTest {

	private Activities list;
	private Activity baloncesto;

	@Before
	public void setUp() throws Exception {
		list = new Activities();
		baloncesto = new Activity("Baloncesto", "Palomera", 0);
	}

	@Test
	public void testActivities() throws ActivityException {
		assertEquals(3, this.list.getSize());
		assertEquals(0, this.list.getNumOfActivities());

	}

	@Test
	public void testGetSize() throws ActivityException {
		assertEquals(3, list.getSize());
	}

	@Test
	public void testExists() throws ActivityException {
		assertFalse(this.list.exist(baloncesto));
		this.list.add(baloncesto);
		assertTrue(this.list.exist(baloncesto));

	}

	@Test
	public void testAdd() throws ActivityException {
		this.list.add(baloncesto);

		assertTrue(this.list.exist(baloncesto));
		assertEquals(1, this.list.getNumOfActivities());
	}

	@Test(expected = ActivityException.class)
	public void testAddNull() throws ActivityException {
		baloncesto = null;
		this.list.add(baloncesto);

	}

	@Test(expected = ActivityException.class)
	public void testAddWhenFull() throws ActivityException {

		Activity musica = new Activity("Musica", "Conservatorio", 0);
		Activity frances = new Activity("Frances", "EOI", 0);
		Activity tenis = new Activity("Tenis", "Chef", 0);

		this.list.add(baloncesto);
		this.list.add(musica);
		this.list.add(frances);
		this.list.add(tenis);
	}

	@Test(expected = ActivityException.class)
	public void testAddAlreadyAdded() throws ActivityException {
		this.list.add(baloncesto);
		this.list.add(baloncesto);
	}

	@Test
	public void testRemove() throws ActivityException {
		this.list.add(baloncesto);
		assertTrue(this.list.exist(baloncesto));
		assertEquals(1, this.list.getNumOfActivities());

		this.list.remove("Baloncesto", 0);
		assertFalse(this.list.exist(baloncesto));
		assertEquals(0, this.list.getNumOfActivities());
	}

	@Test(expected = ActivityException.class)
	public void testRemoveIfNull() throws ActivityException {
		this.list.add(baloncesto);
		this.list.remove("Musica", 0);
	}

	@Test
	public void testRemoveNotFirstActivity() throws ActivityException {
		this.list.add(baloncesto);
		Activity baloncesto2 = new Activity("BaloncestoDos", "Palomera", 1);
		Activity frances = new Activity("Frances", "EOI", 0);

		this.list.add(baloncesto2);
		this.list.add(frances);

		assertTrue(this.list.exist(baloncesto));
		assertTrue(this.list.exist(frances));

		assertTrue(this.list.exist(baloncesto2));
		assertEquals(3, this.list.getNumOfActivities());

		this.list.remove("BaloncestoDos", 1);
		this.list.remove("Frances", 0);
		assertFalse(this.list.exist(baloncesto2));
		assertEquals(1, this.list.getNumOfActivities());
	}

	@Test
	public void testSearch() throws ActivityException {
		Activity musica = new Activity("Musica", "Conservatorio", 0);
		Activity frances = new Activity("Frances", "EOI", 0);
		this.list.add(musica);
		assertTrue(this.list.exist(musica));
		this.list.add(frances);
		assertTrue(this.list.exist(frances));
		this.list.add(baloncesto);
		assertTrue(this.list.exist(baloncesto));
		assertEquals(baloncesto, this.list.search("Baloncesto", 0));

	}

	@Test
	public void testSearchNull() throws ActivityException {
		this.list.add(baloncesto);
		assertTrue(this.list.exist(baloncesto));
		assertNull(this.list.search("Musica", 0));

	}

	@Test
	public void testSearchWrongDay() throws ActivityException {
		this.list.add(baloncesto);
		assertTrue(this.list.exist(baloncesto));
		assertNull(this.list.search("Baloncesto", 1));

	}

	@Test
	public void testGetNumOfActivities() throws ActivityException {
		this.list.add(baloncesto);
		assertTrue(this.list.exist(baloncesto));
		Activity frances = new Activity("Frances", "EOI", 0);
		this.list.add(frances);
		assertTrue(this.list.exist(frances));
		assertEquals(2, this.list.getNumOfActivities());
	}

	@Test
	public void testGet() throws ActivityException {
		this.list.add(baloncesto);
		assertEquals(baloncesto, this.list.get(0));
	}

	@Test
	public void testToString() throws ActivityException {
		this.list.add(baloncesto);
		assertEquals(this.list.search("Baloncesto", 0).toString(), this.list.toString());

	}

}

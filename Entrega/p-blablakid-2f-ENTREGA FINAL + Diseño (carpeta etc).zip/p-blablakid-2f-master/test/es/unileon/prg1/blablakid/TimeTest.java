package es.unileon.prg1.blablakid;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class TimeTest {
	private Time time;
	private Time time2;

	@Before
	public void setUp() throws Exception {
		this.time = new Time(16, 15);
		this.time2 = new Time(12, 34);
	}

	@Test(expected = TimeException.class)
	public void testSetHourOver23() throws Exception {
		this.time.setHour(24);
	}

	@Test(expected = TimeException.class)
	public void testSetNegativeHour() throws Exception {
		this.time.setHour(-2);
	}

	@Test
	public void testSetHour() throws Exception {
		this.time.setHour(18);
		assertEquals(this.time.getHour(), 18);
	}

	@Test(expected = TimeException.class)
	public void testSetMinuteOver59() throws Exception {
		this.time.setMinute(60);
	}

	@Test(expected = TimeException.class)
	public void testSetNegativeMinute() throws Exception {
		this.time.setMinute(-3);
	}

	@Test
	public void testSetMinute() throws Exception {
		this.time.setMinute(18);
		assertEquals(this.time.getMinute(), 18);
	}

	@Test
	public void testGetHour() throws Exception {
		assertEquals(this.time.getHour(), 16);
	}

	@Test
	public void testGetMinute() throws Exception {
		assertEquals(this.time.getMinute(), 15);
	}

	@Test
	public void testEqualsToTrue() throws Exception {
		Time otherTime = new Time(16, 15);
		assertTrue(this.time.equalsTo(otherTime));
	}

	@Test
	public void testEqualsToFalseMinute() throws Exception {
		Time otherTime = new Time(16, 14);
		assertFalse(this.time.equalsTo(otherTime));
	}

	@Test
	public void testEqualsToFalseHour() throws Exception {
		Time otherTime = new Time(18, 15);
		assertFalse(this.time.equalsTo(otherTime));
	}

	@Test
	public void testCompareTo() throws Exception {
		Time otherTime = new Time(18, 16);
		assertEquals(this.time.compareTo(otherTime), -121);
	}

	@Test
	public void testToString() throws Exception {
		assertEquals(this.time2.toString(), this.time2.getHour() + ":" + this.time2.getMinute());
	}

}
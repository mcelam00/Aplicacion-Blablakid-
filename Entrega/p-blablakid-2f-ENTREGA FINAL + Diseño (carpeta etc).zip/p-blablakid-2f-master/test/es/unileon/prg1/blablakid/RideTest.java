package es.unileon.prg1.blablakid;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class RideTest {

	private Ride ride;
	private Time timeS;
	private Time timeE;

	@Before
	public void setUp() throws Exception {
		timeS = new Time(12, 30);
		timeE = new Time(14, 30);
		ride = new Ride("StartPoint", "EndPoint", timeS, timeE);
	}

	@Test(expected = RideException.class)
	public void testCreateInvalidRideTime() throws RideException {
		ride = new Ride("StartPoint", "EndPoint", timeE, timeS);
	}

	@Test(expected = RideException.class)
	public void testCreateInvalidRidePlaceStart() throws RideException {
		ride = new Ride("", "EndPoint", timeS, timeE);
	}

	@Test(expected = RideException.class)
	public void testCreateInvalidRidePlaceEnd() throws RideException {
		ride = new Ride("StartPoint", "", timeS, timeE);
	}

	@Test(expected = RideException.class)
	public void testCreateInvalidRidePlaceBoth() throws RideException {
		ride = new Ride("", "", timeS, timeE);
	}

	@Test
	public void testCreateValidRide() throws RideException {
		assertEquals(true, timeS.equalsTo(ride.getStartTime()));
		assertEquals(true, timeE.equalsTo(ride.getEndTime()));
		assertEquals("StartPoint", ride.getStartPoint());
		assertEquals("EndPoint", ride.getEndPoint());
	}

	@Test
	public void testEqualsTo() throws RideException, TimeException {
		Time timeS2 = new Time(11, 30);
		Time timeE2 = new Time(13, 30);
		Ride sameRide = new Ride("StartPoint", "EndPoint", timeS, timeE);
		Ride changeSP = new Ride("other", "EndPoint", timeS, timeE);
		Ride changeEP = new Ride("StartPoint", "EP", timeS, timeE);
		Ride changeTS = new Ride("StartPoint", "EndPoint", timeS2, timeE);
		Ride changeTE = new Ride("StartPoint", "EndPoint", timeS, timeE2);

		assertEquals(true, ride.equalsTo(sameRide));
		assertEquals(false, ride.equalsTo(changeSP));
		assertEquals(false, ride.equalsTo(changeEP));
		assertEquals(false, ride.equalsTo(changeTS));
		assertEquals(false, ride.equalsTo(changeTE));
	}

	@Test

	public void testToString() {
		assertEquals("StartPoint > EndPoint : 12:30/14:30", ride.toString());
	}
}
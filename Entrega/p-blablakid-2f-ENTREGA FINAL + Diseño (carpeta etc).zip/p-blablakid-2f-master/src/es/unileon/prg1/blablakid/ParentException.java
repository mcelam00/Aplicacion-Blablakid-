package es.unileon.prg1.blablakid;

/**
 * Class in charge of the handling of the exceptions in the classes Parent and Parents.
 *
 * @author Mario Celada Matias
 * @version 0.9
 */

public class ParentException extends Exception {

	public ParentException(String message){
		super(message);
	}
	
}

package es.unileon.prg1.blablakid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Class added responsible Kids
 *
 * @author Roberto Viejo Lopez
 * @version 0.9
 */

public class Kids {
	/**
	 * Attribute of logs
	 */
	private static final Logger logger = LogManager.getLogger(Kids.class);
	/**
	 * Kids array where the kids are stored
	 */
	private Kid[] list;
	/**
	 * Next free position on the kids array
	 */
	private int next;
	/**
	 * Max quantity of kids
	 */
	private int size;

	/**
	 * Class constructor that inicializates its atributes
	 * 
	 * @param size size of the list
	 */
	public Kids(int size) {
		this.size = size;
		this.list = new Kid[size];
		this.next = 0;
	}

	/**
	 * Method that returns a kid from the list
	 * 
	 * @param kid number of the list that you want to return
	 * @return The kid in that position
	 */
	public Kid get(int kid) {
		Kid kiddo;
		kiddo = this.list[kid];
	
		return kiddo;
	}

	/**
	 * Return the number of kids that are in the array
	 * 
	 * @return number of kids that are in the array
	 */
	public int getNumberOfKids() {
		return this.next;
	}

	/**
	 * Method that adds a kid to the list It throws exception if the list is full,
	 * the kid is already in the list or the parameter is null
	 *
	 * @param kid Kid that we are going to add
	 * @throws KidException Throws exception if the list is full, the kid is already
	 *                      in the list or the parameter is null
	 */
	public void add(Kid kid) throws KidException {
		StringBuffer excp = new StringBuffer();

		if (kid == null) {
			logger.error("Tried to add a kid but it was null");
			excp.append("ERROR: Invalid Kid");
		}
		if ((this.next < size) == false) {
			logger.error("Tried to add a kid called " + kid.getName() + " but the list was full");
			excp.append("ERROR: Array of Kids is full");
		}
		if ((exist(kid)) == true) {
			logger.error("Tried to add d kid called " + kid.getName() + " but it was already in the list");
			excp.append("ERROR: " + kid.getName() + " already exists");
		}
		if (excp.length() != 0) {
			throw new KidException(excp.toString());
		} else {
			logger.info("Kid called " + kid.getName() + " was added successfully to the list");
			this.list[this.next] = kid;
			next++;
		}
	}

	/**
	 * Method that removes a kid from the list
	 *
	 * @param kid Kid to remove
	 * @throws KidException Throws exception if the kid does not exist or the
	 *                      parameter is null
	 */
	public void remove(Kid kid) throws KidException {
		if (kid == null || this.exist(kid) == false) {
			throw new KidException("ERROR: Kid does not exist");
		}
		logger.info("Kid called " + kid.getName() + " was removed correctly");
		this.change(searchPosition(kid.getName()), next - 1);
		this.list[next - 1] = null;
		next--;
	}

	/**
	 * Method that search a kid in the list and return it
	 *
	 * @param name Kid's name
	 *
	 * @return Kid if it is in the list or null if it is not in the list
	 */
	public Kid search(String name) {
		Kid kidd = null;
		boolean finish = false;
		int i = 0;
	
		while (!finish && i < this.size) {
			if (this.list[i] != null) {
				if (this.list[i].compareTo(name) == 0) {
					kidd = this.list[i];
					finish = true;
				}
				i++;
			} else {
				finish = true;
			}
		}
		return kidd;
	}

	/**
	 * Method that search a kid in the list and return its position
	 *
	 * @param name Kid's name
	 *
	 * @return Kids position or -1 if it does not exist
	 */
	public int searchPosition(String name) {
		int position = -1;
		boolean finish = false;
		int i = 0;
	
		while (!finish && i < this.size) {
			if (this.list[i] != null) {
				if (this.list[i].compareTo(name) == 0) {
					position = i;
					finish = true;
				}
				i++;
			} else {
				finish = true;
			}
		}
		return position;
	}

	/**
	 * Method that search a kid and tells if it exist
	 * 
	 * @param kid Kid that we want to find
	 * 
	 * @return True if it exists or false if it does not
	 */
	public boolean exist(Kid kid) {
		boolean exist = false;
		if (kid != null) {
			if ((search(kid.getName())) != null) {
				exist = true;
			}
		}
		return exist;
	}

	/**
	 * Method that switch two kids
	 * 
	 * @param i Position one to switch
	 *
	 * @param j Position two to switch
	 */
	private void change(int i, int j) {
		Kid aux = list[i];
		list[i] = list[j];
		list[j] = aux;
	}

	/**
	 * ToString of Kids
	 * 
	 * @return kids as a string
	 */
	@Override
	public String toString() {
		StringBuffer output = new StringBuffer();
		int i = 0;
		boolean searching = true;

		while (searching && i < this.size) {
			if (this.list[i] != null) {
				output.append(this.list[i].toString() + "\n");
				i++;
			} else {
				searching = false;
			}
		}
		return output.toString();
	}

}

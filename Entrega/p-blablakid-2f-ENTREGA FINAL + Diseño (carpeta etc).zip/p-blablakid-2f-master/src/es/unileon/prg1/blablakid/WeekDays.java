package es.unileon.prg1.blablakid;

public enum WeekDays {
	
	MONDAY, TUESDAY, WEDNESDAY,
    THURSDAY, FRIDAY

}

package es.unileon.prg1.blablakid;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;

/**
 * Class that added to Activity
 *
 * @author Angel Gonzalez Gonzalez
 * @version 0.9
 */

public class Activities {

	/**
	 * Attribute of logs
	 */
	private static final Logger logger = LogManager.getLogger(Activities.class);

	/**
	 * 
	 * Array of Activities that contain the activities
	 * 
	 */
	private Activity[] list;

	/**
	 * 
	 * Next free position in the array of Activities
	 * 
	 */
	private int next;

	/**
	 * 
	 * Quantity max of Activities
	 * 
	 */
	private int size;

	/**
	 *
	 * Constructor of the Activities class that initializes its attributes
	 * 
	 */
	public Activities() {

		this.list = new Activity[3];
		this.next = 0;
		this.size = 3;
	}

	/**
	 * That method is for get the maximum size that is 3
	 * 
	 * @return the size
	 */
	public int getSize() {
		return this.size;
	}

	public Activity get(int act) {
		return this.list[act];
	}

	/**
	 * 
	 * Method that returns the number of activities
	 * 
	 * @return Number of activities
	 */
	public int getNumOfActivities() {
		return this.next;
	}

	/**
	 * 
	 * Class that add an activity
	 * 
	 * @param activity Activity that we are going to add
	 * 
	 * @throws ActivityException Throws exception if the list is full, the Activity
	 *                           is already in the list or the parameter is null
	 */
	public void add(Activity activity) throws ActivityException {

		if (activity == null) {
			logger.error("Tried to add an Activity but it was null");
			throw new ActivityException("ERROR: Invalid Activity");
		} else if ((this.next < size) == false) {
			logger.error("Tried to add an Activity called " + activity.getName() + " but the list was full");
			throw new ActivityException("ERROR: Array of Activities is full");
		} else if ((exist(activity)) == true) {
			logger.error("Tried to add an Activity called " + activity.getName() + " but it was already in the list");
			throw new ActivityException("ERROR: " + activity.getName() + " already exists");
		} else {
			logger.info("Activity called " + activity.getName() + " was added successfully to the list");
			this.list[this.next] = activity;
			this.next++;
		}
	}

	/**
	 * Method that search an Activity and tells if it already exists.
	 * 
	 * @param activity Activity that we want to find
	 * @return True if it exists or false if it does not
	 */
	public boolean exist(Activity activity) {

		boolean exists = false;

		if (this.search(activity.getName(), activity.getDayOrdinal()) != null) {
			exists = true;
		}
		return exists;
	}

	/**
	 * Method that removes an activity from the list
	 * 
	 * @param activityName Name of the activity to be removed
	 * @param day          Day when the activity is made
	 * @throws ActivityException If the activity does not exist
	 */
	public void remove(String activityName, int day) throws ActivityException {
		Activity activity = this.search(activityName, day);

		if (activity == null) {
			logger.error("Tried to remove an Activity called " + activityName + " that is not in the list");
			throw new ActivityException("ERROR: Activity does not exist");
		} else {
			logger.info("Activity called " + activity.getName() + " was removed correctly");
			this.change(this.searchPosition(activity.getName(), activity.getDayOrdinal()), this.next - 1);
			this.list[this.next - 1] = null;
			this.next--;
		}
	}

	/**
	 * Method that search for an activity
	 * 
	 * @param name Name of the activity
	 * @param day  Day when the activity is made
	 * @return The activity it it has been found or null if it hasn't
	 */
	public Activity search(String name, int day) {
		Activity activity = null;
		boolean searching = true;
		int i = 0;

		while (searching && i < this.next) {

			if (this.list[i].getName().equalsIgnoreCase(name) && this.list[i].getDay() == WeekDays.values()[day]) {

				searching = false;

				activity = this.list[i];

			} else {

				i++;
			}

		}
		return activity;
	}

	/**
	 * Private method that search for the position of an activity
	 * 
	 * @param name Name of the activity
	 * @param day  Day when the activity is made
	 * @return The position of the activity
	 */
	private int searchPosition(String name, int day) {

		int position = -1;
		boolean searching = true;
		int i = 0;

		while (searching && i < this.next) {

			if (this.list[i].getName() == name && this.list[i].getDay() == WeekDays.values()[day]) {

				searching = false;

				position = i;

			} else {

				i++;
			}

		}
		return position;
	}

	/**
	 * 
	 * Method that switch two Activities
	 * 
	 * @param i Position one to switch
	 * @param j Position two to switch
	 */
	private void change(int i, int j) {
		Activity aux = list[i];
		list[i] = list[j];
		list[j] = aux;
	}

	/**
	 * toString method
	 * 
	 * @return activities as a string
	 */
	@Override
	public String toString() {
		StringBuilder output = new StringBuilder();
		for (int i = 0; i < this.next; i++) {
			output.append(this.list[i]);
		}
		return output.toString();
	}

}
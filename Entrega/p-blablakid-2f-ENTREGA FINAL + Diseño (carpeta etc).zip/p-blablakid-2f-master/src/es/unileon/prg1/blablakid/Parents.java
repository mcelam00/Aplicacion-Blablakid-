package es.unileon.prg1.blablakid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 
 * Class that represents the Array in which the Parent objects are included.
 * Aggregate class of Parent.
 *
 * @author Mario Celada Matias
 * @version 0.9
 */

public class Parents {

	/**
	 * Attribute of logs
	 */
	private static final Logger logger = LogManager.getLogger(Parents.class);
	/**
	 * Parents array in which the Parent objects are stored.
	 */

	private Parent[] list;

	/**
	 * Next empty position in the array, or the number of full positions.
	 */

	private int next;

	/**
	 * The size of the array.
	 */

	private int size;

	/**
	 * Class constructor, it creates the array of objects of the Parent type with
	 * the size which is received as a parameter.
	 * 
	 * @param size The size of the array.
	 */

	public Parents(int size) {
		this.setSize(size);
		logger.info("List of Parents sucesfully created");
	}

	/**
	 * Method that returns the object of Parent type according to the position which
	 * is passed.
	 * 
	 * @param position The position of the array from where we want to take the
	 *                 parent.
	 * @return The object of Parent type.
	 * @throws ParentException ERROR if the position is invalid
	 */
	public Parent get(int position) throws ParentException {

		Parent parent;

		if (position < 0 || position > this.size - 1) {
			logger.error("Attempt to get the parent object in a given position (" + position
					+ ") but the position is not valid, is out of bounds of the parents array");
			throw new ParentException("ERROR: Invalid position of the array");
		} else {
			parent = this.list[position];
		}

		return parent;

	}

	/**
	 * Return the number of parents
	 * 
	 * @return the number of parents
	 */
	public int getNumberOfParents() {
		return this.next;
	}

	/**
	 * Method which returns the size of the array.
	 * 
	 * @return Integer that indicates the size.
	 */
	public int getSize() {
		return this.size;
	}

	/**
	 * Method which ensures that the parameter is correct when assigning values to
	 * the attributes of the class.
	 * 
	 * @param size The number of positions of the array.
	 */
	public void setSize(int size) {
		this.size = size;
		this.list = new Parent[size];
		this.next = 0;
	}

	/**
	 * Method which adds a new Parent to the array Parents.
	 * 
	 * @param parent The Parent to add.
	 * @throws ParentException Error if we try to add a Parent which already exists
	 *                         in the array.
	 */
	public void add(Parent parent) throws ParentException {

		if (parent == null) {
			logger.error("Attempt to introduce a null parent");
			throw new ParentException("ERROR: Invalid Activity");
		} else if (this.exists(parent) == true) {
			logger.error("Attempt to introduce a parent named " + parent.getName() + " which is already on the list");
			throw new ParentException("ERROR: Parent " + parent.getName() + " already exists in the Array");
		} else if (this.next == this.size) {
			logger.info(
					"Attempt to introduce a parent named " + parent.getName() + " but the array of parents is full");
			;
			throw new ParentException("ERROR: The Parents Array is full");
		} else {
			this.list[this.next] = parent;
			this.next++;
			logger.info("Parent " + parent.getName() + " sucesfully added");

		}

	}

	/**
	 * Method which deletes a Parent from the array.
	 * 
	 * @param parent The Parent to remove
	 * 
	 * @throws ParentException Error if we try to delete a Parent which has already
	 *                         been deleted before.
	 */
	public void remove(Parent parent) throws ParentException {
		int position;
		if (parent == null) {
			logger.error("Attempt to remove a null parent");
			throw new ParentException("ERROR: Parent not found");
		} else if (this.exists(parent) == false) {
			logger.error("Attempt to remove parent " + parent.getName()
					+ " which is not in the list, either because it was never added, or beacause it has already been deleted before");
			throw new ParentException("ERROR: Parent not found");
		}
		position = this.searchPosition(parent.getName());
		this.list[position] = null;
		this.change(position, this.next - 1);
		this.next--;
		logger.info("Parent " + parent.getName() + " succesfully removed");

	}

	/**
	 * Method which searches a Parent (which is passed as a parameter) and it
	 * returns it if it finds it.
	 * 
	 * @param name Name of the Parent to search.
	 * 
	 * @return The Parent type object if it finds it or null if it does not find it.
	 * 
	 */
	public Parent search(String name) {
		int counter = 0;
		Parent parent = null;

		while (counter < this.next && parent == null) {

			if (this.list[counter].getName().toLowerCase().compareTo(name.toLowerCase()) == 0) {
				parent = this.list[counter];

			} else {
				counter++;
			}
		}

		return parent;
	}

	/**
	 * Method which searches a Parent (which is passed as a parameter) and returns
	 * its position in the array.
	 * 
	 * @param name Name of the Parent to search.
	 * 
	 * @return Integer which indicates its position.
	 */
	public int searchPosition(String name) {
		int counter = 0;
		Parent parent = null;

		while (counter < this.next && parent == null) {

			if (this.list[counter].getName().toLowerCase().compareTo(name.toLowerCase()) == 0) {
				parent = this.list[counter];

			} else {
				counter++;
			}
		}

		return counter;
	}

	/**
	 * Method which checks if the Parent which is received already exists on the
	 * array.
	 * 
	 * @param parent Parent which is received.
	 * @return true if the Parent is already on the array. false if the parent is
	 *         not included in the array.
	 * 
	 */
	private boolean exists(Parent parent) {
		boolean exist;
		String name;
		exist = false;
		name = parent.getName();

		if (this.search(name) != null) {
			exist = true;
		}
		return exist;
	}

	/**
	 * Method which exchanges 2 positions of an array.
	 * 
	 * @param i First position to exchange.
	 * 
	 * @param j Second position to exchange.
	 */
	private void change(int i, int j) {
		Parent aux;

		aux = this.list[i];

		this.list[i] = this.list[j];
		this.list[j] = aux;
	}

	/**
	 * Method which prints the information of the class in String format.
	 * 
	 * @return The array information as a String.
	 */
	@Override
	public String toString() {
		StringBuilder output = new StringBuilder();

		for (int i = 0; i < this.next; i++) {
			output.append(this.list[i].toString());
		}

		return output.toString();
	}

}

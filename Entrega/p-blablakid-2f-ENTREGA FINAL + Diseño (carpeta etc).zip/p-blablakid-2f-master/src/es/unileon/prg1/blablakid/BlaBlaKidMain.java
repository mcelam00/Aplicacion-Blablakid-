package es.unileon.prg1.blablakid;

/**
 * Clase main
 *
 * @author Roberto Viejo Lopez
 * @version 0.9
 */

public class BlaBlaKidMain {

	public static void main(String[] args) {
		int maxKids = -1;
		if (args.length != 1) {
			System.out.println("ERROR: You must introduce an argument with the max number of kids");
		} else {
			try {
				maxKids = Integer.parseInt(args[0]);
				if (maxKids <= 0) {
					System.out.println("ERROR: The number of kids must be at least 1");
				} else {
					Blablakid blablakid = new Blablakid(maxKids);
					TextUI textUI = new TextUI(blablakid);
					textUI.start();
				}
			} catch (NumberFormatException e) {
				System.out.println(e.getMessage());
			}
		}

	}
}

package es.unileon.prg1.blablakid;

/**
 * Clase encargada de la gestion de excepciones en Blablakid
 *
 * @author Roberto Viejo Lopez
 * @version 0.9
 */


public class BlablakidException extends Exception {
	
	public BlablakidException(String message){
		super(message);
	}

}


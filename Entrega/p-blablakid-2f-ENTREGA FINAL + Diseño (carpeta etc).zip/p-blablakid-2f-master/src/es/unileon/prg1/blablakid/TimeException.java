package es.unileon.prg1.blablakid;

/**
 * Clase encargada de la gestion de excepciones en Time
 *
 * @author Diego Castellanio Ruiz
 * @version 0.9
 */


public class TimeException extends Exception {
	
	public TimeException(String message){
		super(message);
	}

}


package es.unileon.prg1.blablakid;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;

/**
 * Class that represents a kid
 *
 * @author Roberto Viejo Lopez
 * @version 0.9
 */

public class Kid {
	/**
	 * Attribute of logs
	 */
	private static final Logger logger = LogManager.getLogger(Kid.class);
	/**
	 * Kid's name
	 *
	 * @see String
	 */
	private String name;
	/**
	 * Kid's activities
	 */
	private Activities activities;

	/**
	 * Class constructor, it creates a kid with the given information
	 *
	 * @param name Kid's name
	 * @throws KidException If the name is not valid it throws exception
	 */
	public Kid(String name) throws KidException {
		this.activities = new Activities();
		this.setName(name);
	}

	/**
	 * Method that returns the kid's name
	 *
	 * @return Name of the current kid
	 */
	public String getName() {
	
		return this.name;
	}

	/**
	 * Method that returns an activity
	 * 
	 * @param act Number of the activity friem activities
	 * @return The activity
	 */
	public Activity getActivity(int act) {
		return this.activities.get(act);
	}

	/**
	 * Method that returns the number of activities that the current kid has
	 *
	 * @return Number of activities
	 */
	public int getNumOfActivities() {
	
		return this.activities.getNumOfActivities();
	}

	/**
	 * Method that sets the name if it is valid
	 *
	 * @param name Kid's name
	 * @throws KidException If the name is not valid it throws exception
	 */
	private void setName(String name) throws KidException {
		boolean valid = this.checkName(name);
		if (!valid) {
			logger.error("Tried to create kid called " + name + " but the name was not valid");
			throw new KidException("ERROR: Invalid kid name, introduce only letters");
		} else {
			logger.info("Created kid called " + name + " successfully");
			this.name = name;
		}
	}

	/**
	 * Method that adds a ride to the activity
	 * 
	 * @param ride         Ride to be added
	 * @param activityName Activity where the ride belongs to
	 * @param day          Day of the activity
	 * @return If it has been aded
	 * @throws ActivityException If there's a problem with the activity
	 */
	public boolean addRide(Ride ride, String activityName, int day) throws ActivityException {
		Activity activity = this.activities.search(activityName, day);
		return activity.addRide(ride);
	}

	/**
	 * Method that adds an activity to activities aggregate
	 *
	 * @param activity activity that you are going to add
	 * @throws ActivityException if the activity already exists it throws an error
	 */
	public void addActivity(Activity activity) throws ActivityException {
		this.activities.add(activity);
	}

	/**
	 * Method that removes a ride from the activity
	 * 
	 * @param ride Ride to be removed
	 * @return True if it hasn't been removed or false if it has
	 */
	public boolean removeRide(Ride ride) {
	
		boolean searching = true;
		int i = 0;
	
		while (searching && i < this.activities.getNumOfActivities()) {
			Activity activity = this.activities.get(i);
			searching = activity.removeRide(ride);
			i++;
		}
		return searching;
	}

	/**
	 * Method that removes an activity to activities aggregate
	 *
	 * @param activity name of the activity that you are going to remove
	 * @param day      day when the activity takes place
	 * @throws ActivityException if the activity does not exist it throws an error
	 */
	public void removeActivity(String activity, int day) throws ActivityException {
		this.activities.remove(activity, day);
	}

	/**
	 * Method that compares one day with other
	 * 
	 * @param kid Kid to compare
	 * @return negative if the current kid is smaller alphabetically that the one
	 *         recived in the parameter 0 if are both are the same day positive if
	 *         the current kid is bigger alphabetically that the one recived in the
	 *         parameter
	 */
	public int compareTo(Kid kid) {
		int comparation;
		if ((this.name.equalsIgnoreCase(kid.getName())) == true) {
			comparation = 0;
		} else {
			comparation = (this.name.toLowerCase().compareTo(kid.getName().toLowerCase()));
		}
	
		return comparation;
	}

	/**
	 * Method that compares one day with other
	 * 
	 * @param other name of the kid to compare
	 * @return negative if the current kid is smaller alphabetically that the one
	 *         received in the parameter 0 if are both are the same day positive if
	 *         the current kid is bigger alphabetically that the one received in the
	 *         parameter
	 */
	public int compareTo(String other) {
		int comparation;
	
		if ((this.name.equalsIgnoreCase(other)) == true) {
			comparation = 0;
		} else {
			comparation = (this.name.toLowerCase().compareTo(other.toLowerCase()));
		}
	
		return comparation;
	}

	/**
	 * Method that checks a name and tells if it is valid
	 * 
	 * @param name Kid's name
	 * @return True if it is valid or false if it is not valid
	 */
	private boolean checkName(String name) {
		boolean valid = true;
		String validChar = "ABCDEFGHIJKLMNOPQRSTUVWXYZ ";

		if (name.length() == 0) {
			valid = false;

		}
		int counter = 0;
		while (valid && counter < name.length()) {
			if ((validChar.contains((String.valueOf(name.charAt(counter)).toUpperCase()))) == false) {

				valid = false;
			}
			counter++;
		}

		return valid;
	}

	/**
	 * ToString of kid
	 * 
	 * @return the kid as a string
	 */
	@Override
	public String toString() {
		StringBuilder output = new StringBuilder();
		output.append("****** " + this.name + " ******\n");
		output.append(this.activities.toString());
		return output.toString();
	}
}

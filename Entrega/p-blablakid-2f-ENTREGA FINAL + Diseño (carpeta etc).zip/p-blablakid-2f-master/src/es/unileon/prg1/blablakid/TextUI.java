package es.unileon.prg1.blablakid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Class which is the user interface
 *
 * @author Todos
 * @version 0.9
 */

public class TextUI {

	/**
	 * Attribute of logs
	 */
	private static final Logger logger = LogManager.getLogger(TextUI.class);

	/**
	 * Class attribute which reference the program
	 */
	private Blablakid blablakid;

	/**
	 * Class constructor, it creates a TextUI
	 *
	 * @param blablakid where the whole program is executed
	 */
	public TextUI(Blablakid blablakid) {
		this.blablakid = blablakid;
	}

	/**
	 * Method that runs the loop of the menu
	 */
	public void start() {
		int option;
		do {
			option = this.doChosenOption();
		} while (option != 0);
	}

	/**
	 * Method which shows the menu
	 * 
	 * @return chosen option
	 */
	private int showMenu() {

		int option = 0;
		this.showSummary();

		System.out.println("---------\r\n" + "Blablakid\r\n" + "---------\r\n" + "Select an option:\r\n"
				+ "1 - Add kid\r\n" + "2 - Remove kid\r\n" + "3 - Add parent\r\n" + "4 - Remove parent\r\n"
				+ "5 - Add activity\r\n" + "6 - Remove activity\r\n" + "7 - Add ride\r\n" + "8 - Remove ride\r\n"
				+ "9 - Show summary\r\n" + "10 - Check status\r\n" + "0 - Exit");
		option = Teclado.readInteger();
		return option;
	}

	/**
	 * Method which do the chosen option
	 * 
	 * @return the option
	 */
	public int doChosenOption() {

		int option;

		option = showMenu();
		try {
			switch (option) {
			case 1:
				logger.info("Selected option 1: Add kid");
				Kid kid = this.askKid();
				this.blablakid.add(kid);
				System.out.println(kid.getName() + " added correctly");
				break;
			case 2:
				logger.info("Selected option 2: Remove kid");
				System.out.println("Name of the kid to remove: ");
				String removedKid = this.askKidName();
				this.blablakid.removeKid(removedKid);
				System.out.println(removedKid + " removed correctly");
				break;

			case 3:
				logger.info("Selected option 3: Add parent");
				Parent parent = this.askParent();
				Kids fakeSons = this.askSons();
				this.blablakid.addParent(parent, fakeSons);
				System.out.println(parent.getName() + " added correctly");
				break;

			case 4:
				logger.info("Selected option 4: Remove parent");
				System.out.println("Name of the parent to remove: ");
				String removedParent = this.askParentName();
				this.blablakid.removeParent(removedParent);
				System.out.println(removedParent + " removed correctly");
				break;

			case 5:
				logger.info("Selected option 5: Add activity");
				Activity activityToAdd = this.askActivity();
				System.out.println("Name of the kid taking the activity: ");
				String kidName = this.askKidName();
				System.out.println("When does the activity start? ");
				Time startTime = this.askTime();
				System.out.println("When does the activity end? ");
				Time endTime = this.askTime();
				activityToAdd.setTime(startTime, endTime);
				this.blablakid.addActivity(activityToAdd, kidName);
				System.out.println(activityToAdd.getName() + " added correctly");
				break;

			case 6:
				logger.info("Selected option 6: Remove activity");
				System.out.println("Name of the kid taking the activity to remove: ");
				String kidNameAct = this.askKidName();
				System.out.println("Name of the activity to remove: ");
				String removedActivityName = this.askActivityName();
				int dayActRemove = this.askDay();
				this.blablakid.removeActivity(removedActivityName, dayActRemove, kidNameAct);
				System.out.println(removedActivityName + " removed correctly");
				break;

			case 7:
				logger.info("Selected option 7: Add ride");
				System.out.println("Name of the parent in charge of the ride: ");
				String rideParentName = this.askParentName();
				System.out.println("Name of the activity of the ride: ");
				String rideActivityName = this.askActivityName();
				System.out.println("Name of the kid taking the activity: ");
				String rideKidName = this.askKidName();
				Ride rideToAdd = this.askRide();
				int nday = this.askDay();
				this.blablakid.addRide(rideToAdd, rideParentName, rideActivityName, rideKidName, nday);
				break;

			case 8:
				logger.info("Selected option 8: Remove ride");
				System.out.println("Name of the parent in charge of the ride: ");
				String rideParentNameR = this.askParentName();

				int ndayR = this.askDay();

				System.out.println("Where does the ride start? ");
				String startPointR = this.askPlace();

				System.out.println("Where does the ride end? ");
				String endPointR = this.askPlace();

				this.blablakid.removeRide(rideParentNameR, ndayR, startPointR, endPointR);

				break;

			case 9:
				logger.info("Selected option 9: Show summary");
				this.showSummary();
				break;

			case 10:
				logger.info("Selected option 10: Check status");
				System.out.println("------ STATUS ------");
				System.out.println(this.blablakid.checkStatus());
				break;

			case 0:
				logger.info("Exiting the program");
				System.out.println("Exiting");
				break;

			default:
				logger.error("Wrong option selected: " + option);
				System.out.println("ERROR: Incorrect option");
				break;
			}
		} catch (BlablakidException e) {
			System.out.println(e.getMessage());
		} catch (KidException e) {
			System.out.println(e.getMessage());
		} catch (ParentException e) {
			System.out.println(e.getMessage());
		} catch (DayException e) {
			System.out.println(e.getMessage());
		} catch (TimeException e) {
			System.out.println(e.getMessage());
		} catch (ActivityException e) {
			System.out.println(e.getMessage());
		} catch (RideException e) {
			System.out.println(e.getMessage());
		}
		return option;
	}

	/**
	 * Method that asks for the information to create a kid
	 * 
	 * @return The created kid
	 * @throws KidException       If there's been a problem related to kid
	 * @throws BlablakidException If there's been a problem with the name
	 */
	private Kid askKid() throws KidException, BlablakidException {

		System.out.println("Name of the kid to add: ");
		String kidName = this.askKidName();

		Kid createdKid = new Kid(kidName);
		return createdKid;
	}

	/**
	 * Method that asks for a kid name
	 * 
	 * @return The name if it is correct
	 * @throws BlablakidException If the name is not correct
	 */
	private String askKidName() throws BlablakidException {
		String kidName = Teclado.readString();

		if (kidName.trim().length() == 0) {
			logger.error("Wrong kid name introduced was empty");
			throw new BlablakidException("ERROR: kid name can not be empty");
		}
		return kidName;
	}

	/**
	 * 
	 */

	/**
	 * Method that asks for the information to create a parent
	 * 
	 * @return Return the created parent
	 * @throws ParentException    If there's been a problem related to parent
	 * @throws DayException       If there's been a problem related to day
	 * @throws BlablakidException If the name is not correct
	 */
	private Parent askParent() throws ParentException, DayException, BlablakidException {

		System.out.println("Name of the parent to add: ");
		String parentName = this.askParentName();

		System.out.println("How many rides can " + parentName + " make per day?");
		int numberOfRides = Teclado.readInteger();

		if ((numberOfRides == Integer.MIN_VALUE) || (numberOfRides <= 0)) {
			logger.error("Number of rides was not right, introduced: " + numberOfRides);
			throw new BlablakidException("ERROR: Number of rides was not right, must be an integer and more than 0");
		}
		Parent createdParent = new Parent(parentName, numberOfRides);

		return createdParent;
	}

	/**
	 * Method that ask for the information to remove a parent
	 * 
	 * @return parent name
	 * @throws BlablakidException If there's been a problem with the input
	 */
	private String askParentName() throws BlablakidException {

		String parentName = Teclado.readString();
		if (parentName.trim().length() == 0) {
			logger.error("Wrong parent name introduced was empty");
			throw new BlablakidException("ERROR: Parent name can not be empty");
		}

		return parentName;
	}

	/**
	 * Method that ask for the sons of the parent
	 * 
	 * @return Array of created sons
	 * @throws KidException       If there's a problem related to kid
	 * @throws BlablakidException If there's been a problem with the input
	 */
	private Kids askSons() throws KidException, BlablakidException {
		System.out.println("How many kids does the parent has?");
		int numberOfKids = Teclado.readInteger();

		if ((numberOfKids == Integer.MIN_VALUE) || (numberOfKids <= 0)) {
			logger.error("Number of kids was not right, introduced: " + numberOfKids);
			throw new BlablakidException("ERROR: Number of kids was not right, must be an integer and more than 0");
		}
		Kids fakeSons = new Kids(numberOfKids);

		for (int i = 0; i < numberOfKids; i++) {
			System.out.println("Who is parent's kid number" + (i + 1));
			fakeSons.add(new Kid(this.askKidName()));
		}
		return fakeSons;
	}

	/**
	 * Method that asks for the information to add activity
	 * 
	 * @return The created activity
	 * @throws ActivityException  If there's a problem related to activity
	 * @throws BlablakidException There's problems with the names
	 */
	private Activity askActivity() throws ActivityException, BlablakidException {

		System.out.println("Name of the activity: ");
		String act = this.askActivityName();

		System.out.println("Where does " + act + " takes place?");
		String plac = Teclado.readString();

		int day = this.askDay();

		Activity created = new Activity(act, plac, day);
		return created;
	}

	/**
	 * Method that asks for an activity name
	 * 
	 * @return The name of the activity
	 * @throws BlablakidException If there's a problem related to the input
	 */
	private String askActivityName() throws BlablakidException {

		String activityName = Teclado.readString();

		if (activityName.trim().length() == 0) {
			logger.error("Wrong activity name introduced was empty");
			throw new BlablakidException("ERROR: Activity name can not be empty");
		}

		return activityName;
	}

	/**
	 * Method that asks for the data to create a ride
	 * 
	 * @return The ride
	 * @throws TimeException      If there's a problem related to time
	 * @throws RideException      If there's a problem related to ride
	 * @throws BlablakidException If there's a problem related to the input
	 */
	private Ride askRide() throws TimeException, RideException, BlablakidException {

		System.out.println("Where does the ride start? ");
		String startPoint = Teclado.readString();

		if (startPoint.trim().length() == 0) {
			logger.error("Wrong start point name introduced was empty");
			throw new BlablakidException("ERROR: Start point name can not be empty");
		}

		System.out.println("Where does the ride end? ");
		String endPoint = Teclado.readString();

		if (endPoint.trim().length() == 0) {
			logger.error("Wrong end point name introduced was empty");
			throw new BlablakidException("ERROR: End point name can not be empty");
		}

		System.out.println("When does the ride start?");
		Time startTime = this.askTime();

		System.out.println("When does the ride end?");
		Time endTime = this.askTime();

		Ride ride = new Ride(startPoint, endPoint, startTime, endTime);

		return ride;
	}

	/**
	 * Method that asks for a place
	 * 
	 * @return Return place name
	 * @throws BlablakidException If there's a problem related to input
	 */
	private String askPlace() throws BlablakidException {

		String placeName = Teclado.readString();

		if (placeName.trim().length() == 0) {
			logger.error("Wrong place name introduced was empty");
			throw new BlablakidException("ERROR: place name can not be empty");
		}

		return placeName;
	}

	/**
	 * Method that ask for a time
	 * 
	 * @return Created time
	 * @throws TimeException      If there's a problem related to time
	 * @throws BlablakidException If there's a problem with the input
	 */
	private Time askTime() throws TimeException, BlablakidException {
		System.out.println("Insert hour: ");
		int hour = Teclado.readInteger();

		if ((hour == Integer.MIN_VALUE) || ((hour < 0 || hour > 23))) {
			logger.error("Wrong hour introduced: " + hour);
			throw new BlablakidException("ERROR: Hour must be an integer between 0 and 23");
		}

		System.out.println("Insert minute: ");
		int minute = Teclado.readInteger();

		if ((minute == Integer.MIN_VALUE) || ((minute < 0 || minute > 59))) {
			logger.error("Wrong minute introduced: " + minute);
			throw new BlablakidException("ERROR: Minute must be an integer between 0 and 59");
		}

		Time time = new Time(hour, minute);
		return time;
	}

	/**
	 * Method that asks for a day
	 * 
	 * @return The day
	 * @throws BlablakidException There's a problem with the input
	 */
	private int askDay() throws BlablakidException {

		System.out.println("Day of the week for it: ");
		System.out.println("Insert the number of the day of the week:");
		System.out.println("0 - Monday / 1- Tuesday / 2 - Wednesday / 3 - Thursday / 4 - Friday");
		int day = Teclado.readInteger();

		if ((day == Integer.MIN_VALUE) || ((day < 0 || day > 4))) {
			logger.error("Wrong day introduced: " + day);
			throw new BlablakidException("ERROR: Day must be an integer between 0 and 4");
		}
		return day;
	}

	/**
	 * Method that shows the summary
	 */
	private void showSummary() {
		System.out.println(this.blablakid.showSummary());
	}

}

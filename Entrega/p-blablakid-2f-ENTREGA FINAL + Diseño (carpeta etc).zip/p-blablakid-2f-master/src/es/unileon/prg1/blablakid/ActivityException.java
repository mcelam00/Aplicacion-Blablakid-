package es.unileon.prg1.blablakid;

/**
 * Clase encargada de la gestion de excepciones en Kid
 *
 * @author Roberto Viejo López
 * @version 0.1
 */


public class ActivityException extends Exception {
	
	public ActivityException(String message){
		super(message);
	}

}


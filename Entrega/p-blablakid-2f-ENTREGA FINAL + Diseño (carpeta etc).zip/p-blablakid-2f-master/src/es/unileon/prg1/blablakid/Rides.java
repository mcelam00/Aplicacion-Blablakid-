package es.unileon.prg1.blablakid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Clase agregado encargada Rides
 *
 * @author Diego Castellano Ruiz
 * @version 0.9
 */

public class Rides {
	/**
	 * Attribute of logs
	 */
	private static final Logger logger = LogManager.getLogger(Rides.class);
	/**
	 * Rides array where the rides are stored
	 */
	private Ride[] list;
	/**
	 * Next free position on the rides array
	 */
	private int next;
	/**
	 * Max quantity of rides
	 */
	private int size;

	/**
	 * Class constructor that initializes its attributes
	 * 
	 * @param size size of the list
	 */
	public Rides(int size) {
		this.size = size;
		this.list = new Ride[size];
		this.next = 0;
	}

	/**
	 * Return the size of the class
	 * 
	 * @return size of the class
	 */
	public int getSize() {
		return this.size;
	}

	/**
	 * Method which return a ride
	 * 
	 * @param pos Position of the ride
	 * @return Ride
	 */
	public Ride getRide(int pos) {
		return this.list[pos];
	}

	/**
	 * Method that returns the number of rides in the list
	 * 
	 * @return Number of rides in the list
	 */
	public int getNumberOfRides() {
		return this.next;
	}

	/**
	 * Method that adds a ride to the list
	 *
	 * @param ride Ride that we are going to add
	 * @throws RideException Throws exception if the ride is already in the list
	 */
	public void add(Ride ride) throws RideException {
		StringBuffer error = new StringBuffer();
		if (next == size) {
			logger.error("Tried to add a ride but the list was full");
			error.append("ERROR: There've been reached max rides");
		}
		if (ride == null) {
			logger.error("Tried to add a ride but was a null ride");
			error.append("ERROR: The ride was not found");
		} else if (this.search(ride.getStartPoint(), ride.getEndPoint()) != null) {
			logger.error("Tried to add a ride but it already exist");
			error.append("ERROR: There's already a ride with those start and end place");
		}

		if (error.length() != 0) {
			throw new RideException(error.toString());
		} else {
			this.list[this.next] = ride;
			next++;
			logger.info("Tried to add a ride and was succesfully added");
		}

	}

	/**
	 * Method that removes a ride from the list
	 * 
	 * @param ride Ride that is removed
	 * @throws RideException If the ride does not exist
	 */
	public void remove(Ride ride) throws RideException {
		StringBuffer error = new StringBuffer();
		if (ride == null) {
			logger.error("Tried to remove a ride but was a null ride");
			error.append("ERROR: that ride can not be null");
		}
		if (!exist(ride)) {
			logger.error("Tried to remove a ride but was not exist");
			error.append("ERROR: that ride does not exist");
		}
		if (error.length() != 0) {
			throw new RideException(error.toString());
		} else {
			int pos = this.searchPosition(ride);
			this.list[pos] = null;
			this.order(pos);
			next--;
			logger.info("Tried to remove a ride and was succesfully removed");
		}
	}

	/**
	 * Method that search for a ride in the list and returns it if exist
	 * 
	 * @param start Time when the ride start
	 * @param end   Time when the ride ends
	 * @return The ride if it exists or null if it does not
	 */
	public Ride search(String start, String end) {
		int var = 0;
		Ride ride = null;
		while ((var < this.next) && (ride == null) && (this.list[var] != null)) {
			if (start.equalsIgnoreCase(this.list[var].getStartPoint())) {
				if (end.equalsIgnoreCase(this.list[var].getEndPoint())) {
					ride = this.list[var];
				}
			}
			var++;
		}
		return ride;
	}

	/**
	 * 
	 * @param ride The ride which is going to be search
	 * @return The position of the ride
	 */

	private int searchPosition(Ride ride) {
		int var = 0, position = 0;
		while (var < this.next && this.list[var] != null) {
			if (this.list[var].equalsTo(ride)) {
				var = position;
			}
			var++;
		}
		return position;
	}

	/**
	 * Method that check if a ride exist
	 *
	 * @param ride Ride that we are going to check
	 * @return true if it exist else it return false
	 */
	public boolean exist(Ride ride) {
		boolean equals = false;
		int var = 0;
		while ((var < this.next) && (equals == false) && (this.list[var] != null)) {
			if ((this.list[var].getStartPoint().compareTo(ride.getStartPoint()) == 0)
					&& (this.list[var].getEndPoint().compareTo(ride.getEndPoint()) == 0)) {
				equals = true;
			}
			var++;
		}
		return equals;
	}

	/**
	 * Method which order the list
	 * 
	 * @param positionNull The first empty position of the list
	 */
	private void order(int positionNull) {
		this.list[positionNull] = this.list[this.next - 1];
		this.list[this.next - 1] = null;
	}

	/**
	 * Method toString of rides
	 * 
	 * @return rides as a string
	 */
	@Override
	public String toString() {
		StringBuffer salida = new StringBuffer();
		for (int var = 0; var < this.next; var++) {
			salida.append(this.list[var].toString() + "\n");
		}
		return salida.toString();
	}
}

package es.unileon.prg1.blablakid;

/**
 * Class in charge of the creation of a time
 *
 * @author Diego Castellano Ruiz
 * @version 0.9
 */

public class Time {

	/**
	 * Hours integer.
	 * 
	 */

	private int hour;

	/**
	 * Minutes integer.
	 * 
	 */

	private int minute;

	/**
	 * Constructor of the class, it creates a ride with the given information.
	 * 
	 * @param hour   Hour which is received as a parameter.
	 * 
	 * @param minute Minutes received as a parameter.
	 * 
	 * @throws TimeException ERROR if the Hour or Minutes parameters are out of
	 *                       bounds and they do not correspond to a real time.
	 */

	public Time(int hour, int minute) throws TimeException {

		this.setHour(hour);
		this.setMinute(minute);

	}

	/**
	 * Method that return the hours.
	 * 
	 * @return The hours in integer format.
	 */
	
	public int getHour() {
	
		return this.hour;
	}

	/**
	 * Method that returns the minutes.
	 * 
	 * @return The minutes in integer format.
	 */
	
	public int getMinute() {
	
		return this.minute;
	}

	/**
	 * Method that changes the hour of the time.
	 * 
	 * @param hour Hour to set.
	 * 
	 * @throws TimeException ERROR if the Hour which is introduced is out of bounds
	 *                       and they do not correspond to a real hour.
	 */

	public void setHour(int hour) throws TimeException {

		if (hour < 0 || hour > 23) {
			throw new TimeException("Hour " + hour + " not valid" + " Possible values: 0 to 23");
		} else {
			this.hour = hour;
		}
	}

	/**
	 * Method that changes the minutes of the time.
	 * 
	 * @param minute Minutes to set.
	 * 
	 * @throws TimeException ERROR if the Minutes which are introduced are out of
	 *                       bounds and they do not correspond to a real hour.
	 */

	public void setMinute(int minute) throws TimeException {

		if (minute < 0 || minute > 59) {
			throw new TimeException("Minutes " + minute + " not valid" + " Possible values: 0 to 59");
		} else {
			this.minute = minute;
		}
	}

	/**
	 * Method that returns the minute difference between two times.
	 * 
	 * @param time The time which is passed as a parameter.
	 * @return The minute difference in the form of an integer.
	 * 
	 */
	
	public int compareTo(Time time) {
		return (this.hour * 60) - (time.getHour() * 60) + this.minute - time.getMinute();
	}

	/**
	 * Method that compares a two times
	 * 
	 * @param time Time to compare
	 * @return True if it is equal or false if it is not
	 */
	public boolean equalsTo(Time time) {
		boolean equals = true;

		if (this.hour != time.getHour()) {
			equals = false;
		} else if (this.minute != time.getMinute()) {
			equals = false;
		}

		return equals;
	}

	/**
	 * Method that returns the Time data as a String.
	 * 
	 */

	@Override
	public String toString() {
		StringBuffer salida = new StringBuffer();
		salida.append(this.hour + ":" + this.minute);
		return salida.toString();
	}
}

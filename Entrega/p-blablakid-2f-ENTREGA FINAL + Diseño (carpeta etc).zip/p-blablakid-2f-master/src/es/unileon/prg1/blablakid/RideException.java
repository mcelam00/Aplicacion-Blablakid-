package es.unileon.prg1.blablakid;

/**
 * Clase encargada de la gestion de excepciones en Ride
 *
 * @author Roberto Viejo Lopez
 * @version 0.9
 */


public class RideException extends Exception {
	
	public RideException(String message){
		super(message);
	}

}


package es.unileon.prg1.blablakid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Class that represents a ride
 *
 * @author Diego Castellano Ruiz
 * @version 0.9
 */

public class Ride {

	/**
	 * Attribute of logs
	 */
	private static final Logger logger = LogManager.getLogger(Kid.class);
	/**
	 * Start point name
	 *
	 * @see String
	 */
	private String startPoint;
	/**
	 * End point name
	 *
	 * @see String
	 */
	private String endPoint;
	/**
	 * Ride's start time
	 */
	private Time startTime;
	/**
	 * Ride's end time
	 */
	private Time endTime;
	/**
	 * String with errors
	 */
	private StringBuffer error;
	/**
	 * String with errors
	 */
	private StringBuffer logError;

	/**
	 * Class constructor, it creates a ride with the given information
	 *
	 * @param startPoint ride's start point
	 * @param endPoint   ride's end point
	 * @param startTime  ride's start time
	 * @param endTime    ride's end time
	 * @throws RideException If the Ride can not be created
	 */
	public Ride(String startPoint, String endPoint, Time startTime, Time endTime) throws RideException {
		error = new StringBuffer();
		logError = new StringBuffer();
		logger.error("Tried to create ride: " + startPoint + " > " + endPoint + " : " + startTime.toString() + "/"
				+ endTime.toString());
		this.setStartPoint(startPoint);
		this.setEndPoint(endPoint);
		this.setTime(startTime, endTime);
		if (error.toString().length() != 0) {
			logger.error(" but " + logError.toString() + " was/were not valid");
			throw new RideException(error.toString());
		} else {
			logger.info(" And was successfully");
		}
	}

	/**
	 * Method which return ride's start time
	 *
	 * @return ride's start time
	 */
	public Time getStartTime() {
		return this.startTime;
	}

	/**
	 * Method which return ride's end time
	 *
	 * @return ride's end time
	 */
	public Time getEndTime() {
		return this.endTime;
	}

	/**
	 * Method which return ride's start point
	 *
	 * @return ride's start point
	 */
	public String getStartPoint() {
		return startPoint;
	}

	/**
	 * Method which return ride's end point
	 *
	 * @return ride's end point
	 */
	public String getEndPoint() {
		return endPoint;
	}

	/**
	 * Method which check and set the times of the ride
	 * 
	 * @param startTime Time when start
	 * @param endTime   Time when end
	 */
	private void setTime(Time startTime, Time endTime) {
		if (startTime.compareTo(endTime) > 0) {
			error.append("ERROR: Invalid times, start time should be before end time\n");
			logError.append("times");
		} else {
			this.startTime = startTime;
			this.endTime = endTime;
		}
	}

	/**
	 * Method that checks a name and tells if it is valid and set it as start point
	 * 
	 * @param name Place's name
	 */
	private void setStartPoint(String name) {
		if (name.length() == 0) {
			error.append("ERROR: Invalid place name, It can't be null\n");
			logError.append("times");
		} else {
			this.startPoint = name;
		}
	}

	/**
	 * Method that checks a name and tells if it is valid and set it as end point
	 * 
	 * @param name Place's name
	 */
	private void setEndPoint(String name) {
		if (name.length() == 0) {
			error.append("ERROR: Invalid place name, It can't be null\n");
			logError.append("times");
		} else {
			this.endPoint = name;
		}
	}

	/**
	 * Method which check if 2 rides are equals
	 * 
	 * @param ride compared ride
	 * 
	 * @return true if equals and false if not equals
	 */
	public boolean equalsTo(Ride ride) {
		boolean equals = true;

		if (this.startPoint != ride.getStartPoint()) {
			equals = false;
		} else if (this.endPoint != ride.getEndPoint()) {
			equals = false;
		} else if (this.startTime.equalsTo(ride.getStartTime()) == false) {
			equals = false;
		} else if (this.endTime.equalsTo(ride.getEndTime()) == false) {
			equals = false;
		}
		return equals;
	}

	/**
	 * ToString of ride
	 * 
	 * @return ride as a string
	 */
	@Override
	public String toString() {
		StringBuffer salida = new StringBuffer();
		salida.append(startPoint + " > " + endPoint + " : " + startTime.toString() + "/" + endTime.toString());
		return salida.toString();
	}
}

package es.unileon.prg1.blablakid;

/**
 * Clase encargada de la gestion de excepciones en Kid
 *
 * @author Roberto Viejo Lopez
 * @version 0.9
 */


public class KidException extends Exception {
	
	public KidException(String message){
		super(message);
	}

}


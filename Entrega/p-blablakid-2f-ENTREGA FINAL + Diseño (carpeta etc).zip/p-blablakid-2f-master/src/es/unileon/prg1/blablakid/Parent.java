package es.unileon.prg1.blablakid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Class which represents a Parent.
 *
 * @author Mario Celada Matias
 * @version 0.9
 */

public class Parent {

	/**
	 * Attribute of logs
	 */
	private static final Logger logger = LogManager.getLogger(Parent.class);

	/**
	 * Parent name.
	 * 
	 * @see String
	 */
	private String name;

	/**
	 * Array of sons (Kid type) of each Parent.
	 */
	private Kids sons;

	/**
	 * Array of Days (of Day type) of each Parent.
	 */
	private Days days;

	/**
	 * Constructor of the parent
	 * 
	 * @param name          Name of the parent
	 * @param numberOfRides Max numbers of the parent per day
	 * @throws ParentException If there's a problem with adding a parent
	 * @throws DayException    If there's a problem related to the day
	 */
	public Parent(String name, int numberOfRides) throws ParentException, DayException {
		this.setName(name);
		this.setDays(numberOfRides);
	}

	/**
	 * Method which returns the name of the Parent.
	 * 
	 * @return Parent's name.
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * Method which returns the name of the son stored in the position which is
	 * passed as an argument.
	 * 
	 * @param number Position of the sons array.
	 * @throws KidException If there's a problem related to the kid
	 * @return Name of the son in this position.
	 */
	public String getSonName(int number) throws KidException {
		return this.sons.get(number).getName();
	}

	/**
	 * Method that returns the number of rides assigned to a parent.
	 * 
	 * @return The number of rides.
	 */
	public int getNumberOfRides() {
		return this.days.getTotalRides();
	}

	/**
	 * Method that returns the assigned rides in a day
	 * 
	 * @param day Day searching
	 * @return Assigned rides
	 * @throws DayException If there's not any day
	 */
	public int getAssignedRides(int day) throws DayException {
		return this.days.get(day).getNumberOfRides();
	}

	/**
	 * Method that returns the max number of rides that can be stored in a day
	 * 
	 * @param day Number of days
	 * @return Max number of rides
	 * @throws DayException If there's a problem related to the kid
	 */
	public int getMaxRides(int day) throws DayException {
		return this.days.getMaxRides(day);
	}

	/**
	 * Method which return a ride of a day
	 * 
	 * @param numDay  Number of day
	 * @param numRide Position of the ride
	 * @return Ride of a day
	 * @throws DayException If there's a problem related to the day
	 */
	public Ride getRide(int numDay, int numRide) throws DayException {
		return this.days.get(numDay).getRide(numRide);
	}

	/**
	 * Method that set the day
	 * 
	 * @param numberOfRides Max numbers of the parent per day
	 * @throws DayException If there's a problem related to the day
	 */
	public void setDays(int numberOfRides) throws DayException {
		this.days = new Days(numberOfRides);
	}

	/**
	 * Method that sets the parent sons
	 * 
	 * @param sons Sons to be setted
	 */
	public void setSons(Kids sons) {
		this.sons = sons;
	}

	/**
	 * Method that handles the exception and if it is right it sets the name to the
	 * attribute of the class.
	 * 
	 * @param name The name that we want to check and set.
	 *
	 * @throws ParentException ERROR if checkStatus returns false.
	 */
	public void setName(String name) throws ParentException {
		if (this.checkName(name) == false) {
			logger.error("Attempt to create a parent of name " + name
					+ ", but there are characters which are not alphabetical");
			throw new ParentException(
					"ERROR: The name of the Parent is not correct, please use only alphabetical characters");
		} else {
			logger.info("Parent " + name + " succesfully created");
			this.name = name;
		}
	}

	/**
	 * Method which adds a new Ride to the Rides array of each Parent. Throws an
	 * exception if the ride that we are trying to add to the Parent already exists.
	 * 
	 * @param ride    Ride to add.
	 * @param dayName Day of the ride
	 * @throws RideException ERROR if the Ride has already been added.
	 */
	public void addRide(Ride ride, String dayName) throws RideException {
		Day day;

		day = this.days.search(dayName.toUpperCase());
		day.addRide(ride);
	}

	/**
	 * Method which deletes a Ride of the Rides array of each Parent. Throws an
	 * exception if the ride that we want to delete, has already been deleted.
	 * 
	 * @param startPoint Where the ride starts
	 * @param endPoint   Where the ride ends
	 * @param dayName    Ride of the day
	 * @throws RideException If there's a problem related to the ride
	 */
	public void removeRide(String startPoint, String endPoint, String dayName) throws RideException {
		Day day;

		day = this.days.search(dayName.toUpperCase());

		day.removeRide(startPoint, endPoint);

	}

	/**
	 * Removes a kid from sons
	 * 
	 * @param kid Kid to remove
	 * @return True if it hasn't been found or false if it has
	 * @throws KidException If there's a problem related to the kid
	 */
	public boolean removeKid(Kid kid) throws KidException {
		boolean searching = true;
		if (this.sons.exist(kid)) {
			int i = 0;
			while (searching && i < this.sons.getNumberOfKids()) {
				if (this.sons.get(i).compareTo(kid) == 0) {
					this.sons.remove(kid);
					searching = false;
				}
				i++;
			}
		}
		return searching;
	}

	/**
	 * Method that search for a ride in the ride aggregate
	 * 
	 * @param start Where the ride starts
	 * @param end   Where the ride ends
	 * @param day   Ride of the day
	 * @return The ride
	 * @throws RideException If there's a problem related to the ride
	 * @throws DayException  If there's a problem related to the day
	 */
	public Ride searchRide(String start, String end, int day) throws RideException, DayException {

		return this.days.get(day).searchRide(start, end);
	}

	/**
	 * Method that ensures that the name of the Parent only contains alphabetical
	 * characters and it is not an empty field.
	 * 
	 * @param name Name to check.
	 * @return True if the name is correct (alphabetical characters and not empty
	 *         field). False if the name is not correct (not alphabetical characters
	 *         or empty name field).
	 */
	private boolean checkName(String name) {
		boolean valid = true;
		String validChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ ";

		if (name.length() == 0) {
			valid = false;

		} else {

			int counter = 0;
			do {
				if (validChars.contains(String.valueOf(name.charAt(counter)).toUpperCase()) == false) {
					valid = false;
				}
				counter++;
			} while (valid == true && counter < name.length());
		}
		return valid;
	}

	/**
	 * Method that returns all the Parent information as a String.
	 * 
	 * @return String to which all the data is appended.
	 */
	@Override
	public String toString() {

		StringBuilder output = new StringBuilder();
		output.append("\n");
		output.append("###### " + this.name + " ######");
		output.append("\n");
		output.append("Kids:\n");

		for (int i = 0; i < this.sons.getNumberOfKids(); i++) {
			output.append(this.sons.get(i).getName() + "\n");
		}
		output.append("Rides:\n");
		output.append(this.days.toString());

		return output.toString();
	}

}

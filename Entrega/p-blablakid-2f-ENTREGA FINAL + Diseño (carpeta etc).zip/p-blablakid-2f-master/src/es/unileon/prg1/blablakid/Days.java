package es.unileon.prg1.blablakid;

/**
 * Aggregate class of Day
 *
 * @author Roberto Viejo Lopez
 * @version 0.9
 */
public class Days {

	/**
	 * Class attribute where the days are stored
	 */
	private Day[] list;
	/**
	 * Class attribute that has the next free position
	 */
	private int next;
	/**
	 * Number of days that a week has
	 */
	final int WEEK_DAYS = 5;
	/**
	 * Constant of the minimum day
	 */
	final int MIN_DAY = 0;
	/**
	 * Constant of the max day
	 */
	final int MAX_DAY = 4;

	/**
	 * Constructor of the class, initializes the list and the next to 0
	 * 
	 * @param numberOfRides Number of rides
	 * @throws DayException If the day goes out of the bounds
	 */
	public Days(int numberOfRides) throws DayException {
		this.list = new Day[this.WEEK_DAYS];
		this.next = 0;
		this.setDays(numberOfRides);
	}

	/**
	 * Method that returns a day from the list
	 * 
	 * @param day number of the list that you want to return
	 * @return The day in that position
	 *
	 * @throws DayException Throws exception if the day is not in the bounds
	 *
	 */
	public Day get(int day) throws DayException {
		if (day < this.MIN_DAY || day > this.MAX_DAY) {
			throw new DayException("ERROR: Day out of the bounds");
		} else {
			return this.list[day];
		}
	}

	/**
	 * Method that returns the sum of all the rides in the list
	 * 
	 * @return Total rides in the list
	 */
	public int getTotalRides() {
		int rides = 0;
		for (int i = 0; i < this.WEEK_DAYS; i++) {
			rides = rides + this.list[i].getNumberOfRides();
		}
		return rides;
	}

	/**
	 * Method that returns max number of ride
	 * 
	 * @param day Day we're looking for the max rides
	 * @return Total rides can be stored in the list
	 */
	public int getMaxRides(int day) {
		return this.list[day].getMaxRides();
	}

	/**
	 * Method that adds 5 days to the list, with no rides
	 * 
	 * @param numberOfRides Number of rides of the days
	 * @throws DayException If they couldn't be created
	 */
	public void setDays(int numberOfRides) throws DayException {
		while (this.next < this.WEEK_DAYS) {
			this.list[this.next] = new Day(this.next, numberOfRides);
			this.next++;
		}
	}

	/**
	 * Methods that search for a day given its name
	 *
	 * @param name Day's name
	 *
	 * @return Searched day or null if it does not exist
	 */
	public Day search(String name) {
		Day dai = null;
		int counter = 0;
		do {
			if (name.equalsIgnoreCase(this.list[counter].getName())) {
				dai = this.list[counter];
			}
			counter++;
		} while (dai == null && (counter < 5));
		return dai;
	}

	/**
	 * Method that returns the list as a string
	 * 
	 * @return list as a string
	 */
	@Override
	public String toString() {
		StringBuilder output = new StringBuilder();
		for (int i = 0; i < this.WEEK_DAYS; i++) {
			output.append(list[i].toString());
		}
		return output.toString();
	}

}

package es.unileon.prg1.blablakid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Class which represents the starting point of the application.
 *
 * @author Todos
 * @version 0.9
 */

public class Blablakid {
	/**
	 * Attribute of logs
	 */
	private static final Logger logger = LogManager.getLogger(Blablakid.class);
	/**
	 * Class attribute which defines the Kids array.
	 */
	private Kids kidos;

	/**
	 * Class attribute which defines the Parents array.
	 */
	private Parents parentos;

	/**
	 * Constructor of the class, where the max number of Kids and Parents are
	 * initialized.
	 * 
	 * @param kids Size for the kid list
	 */
	public Blablakid(int kids) {

		this.kidos = new Kids(kids);
		this.parentos = new Parents(kids * 2);
	}

	/**
	 * Method that adds a kid to the kids array
	 * 
	 * @param kid kid we want to add
	 * @throws KidException throws exception if the kid already exists in the array
	 */
	public void add(Kid kid) throws KidException {
		kidos.add(kid);
	}

	/**
	 * Method that adds a parent to the array of parents
	 * 
	 * @param parent   parent we want to add
	 * 
	 * @param fakeKids array of the kids we're going to check
	 * 
	 * @throws ParentException    If parent already exists in the array or name is
	 *                            not valid or the array is full
	 * @throws KidException       If the kids are not correctly created
	 * @throws BlablakidException If the parent already exists
	 */
	public void addParent(Parent parent, Kids fakeKids) throws ParentException, KidException, BlablakidException {
		int i = 0;
		Kids sons = new Kids(fakeKids.getNumberOfKids());

		while (i < fakeKids.getNumberOfKids()) {
			Kid kidToAdd = this.kidos.search(fakeKids.get(i).getName());
			if (kidToAdd == null) {
				throw new BlablakidException("ERROR: Kid " + fakeKids.get(i).getName() + " does not exist");
			}
			sons.add(kidToAdd);
			i++;
		}
		parent.setSons(sons);
		this.parentos.add(parent);
	}

	/**
	 * Method that adds an activity to a kid
	 *
	 * @param activity Activity that we're going to add
	 * @param kidName  name of the Kid that takes the activity
	 *
	 * @throws ActivityException  if the activity array of the activities is full or
	 *                            the activity is not valid
	 * @throws BlablakidException If the kid does not exist
	 */
	public void addActivity(Activity activity, String kidName) throws ActivityException, BlablakidException {
		Kid kid = kidos.search(kidName);
		if (kid == null) {
			throw new BlablakidException("ERROR: " + kidName + " does not exist");
		}
		kid.addActivity(activity);
	}

	/**
	 * Method that adds a ride to both, parents and activities
	 * 
	 * @param ride         Ride to be added
	 * @param parentName   Name of the parent of who is the ride
	 * @param activityName Activity to add the ride
	 * @param kidName      Name of the kid who has the activity
	 * @param day          Day when the activity is done
	 * @throws RideException      If there's an error related to ride
	 * @throws KidException       If there's an error related to kid
	 * @throws ActivityException  If there's an error related to activity
	 * @throws BlablakidException if the kid or parent don't exist
	 * @throws DayException       If there's an error related to day
	 */
	public void addRide(Ride ride, String parentName, String activityName, String kidName, int day)
			throws RideException, KidException, ActivityException, BlablakidException, DayException {
		if (this.kidos.search(kidName) == null) {
			throw new KidException("ERROR: the kid " + kidName + " does not exist");
		}
		if (parentos.search(parentName) == null) {
			throw new KidException("ERROR: the kid " + parentName + " does not exist");
		}
		Parent parent = parentos.search(parentName);
		if (parent.getMaxRides(day) == parent.getAssignedRides(day)) {
			throw new BlablakidException(
					"ERROR: " + parentName + " have reached his max rides for " + WeekDays.values()[day].name());
		}
		if (this.kidos.search(kidName).addRide(ride, activityName, day)) {
			parent.addRide(ride, WeekDays.values()[day].name());
		} else {
			throw new BlablakidException("ERROR: This ride does not match with any free activity");
		}
	}

	/**
	 * Method that removes a kid from the kids array
	 *
	 * @param kidName name of the kid we want to remove
	 * @throws KidException       if the kid doesn't exist in the array
	 * @throws ParentException    if the parent does not exist
	 * @throws DayException       if the day is not created right
	 * @throws RideException      if there's a problem with rides
	 * @throws BlablakidException If the kid does not exist
	 *
	 */
	public void removeKid(String kidName)
			throws KidException, ParentException, DayException, RideException, BlablakidException {
		Kid kid = this.kidos.search(kidName);
		if (kidos.exist(kid) == false) {
			logger.error("Tried to remove " + kidName + " but didn't exist");
			throw new BlablakidException("ERROR: Kid does not exist");
		} else {

			for (int j = 0; j < kid.getNumOfActivities(); j++) {

				Ride after = kid.getActivity(j).getAfter();
				Ride before = kid.getActivity(j).getBefore();

				boolean searchingAfter = true;
				if (after == null) {
					searchingAfter = false;
				}
				boolean searchingBefore = true;
				if (before == null) {
					searchingBefore = false;
				}
				int i = 0;

				while ((searchingAfter || searchingBefore) && i < this.parentos.getNumberOfParents()) {
					Parent parent = this.parentos.get(i);
					int k = 0;

					while ((searchingAfter || searchingBefore) && k < 5) {

						if (searchingAfter
								&& parent.searchRide(after.getStartPoint(), after.getEndPoint(), k) != null) {
							parent.removeRide(after.getStartPoint(), after.getEndPoint(),
									WeekDays.values()[k].toString());
							searchingAfter = false;
						}

						if (searchingBefore
								&& parent.searchRide(before.getStartPoint(), before.getEndPoint(), k) != null) {
							parent.removeRide(before.getStartPoint(), before.getEndPoint(),
									WeekDays.values()[k].toString());
							searchingBefore = false;
						}
						k++;
					}
					i++;
				}
			}

			boolean searching = true;
			int i = 0;
			while (searching && i < this.parentos.getNumberOfParents()) {

				searching = this.parentos.get(i).removeKid(kid);
				i++;
			}
			kidos.remove(kid);

		}
	}

	/**
	 * Method that removes a Parent from the array.
	 * 
	 * @param parentName The name of the parent to remove.
	 * @throws ParentException    if the parent to delete has already been deleted
	 *                            and it is not in the list.
	 * @throws DayException       if the day is not created right
	 * @throws RideException      if there's a problem with rides
	 * @throws BlablakidException If the parent does not exist
	 * 
	 */
	public void removeParent(String parentName)
			throws ParentException, BlablakidException, DayException, RideException {
		Parent parent;
		parent = this.parentos.search(parentName);
		if (parent == null) {
			throw new BlablakidException("ERROR: " + parentName + " does not exist");
		}
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < parent.getMaxRides(i); j++) {
				Ride ride = parent.getRide(i, j);
				if (ride != null) {
					boolean searching = true;
					int k = 0;
					while (searching && k < this.kidos.getNumberOfKids()) {
						searching = this.kidos.get(k).removeRide(ride);
						k++;
					}
				}
			}
		}
		this.parentos.remove(parent);
	}

	/**
	 * Method that removes an activity of kid
	 * 
	 * @param activity Name of the activity that we're going to add
	 * @param day      Day of the activity
	 * @param kidName  Name of the Kid that takes the activity
	 * @throws ActivityException  If the activity is not in the array
	 * @throws KidException       If there's an error related to day
	 * @throws ParentException    If there's an error related to parent
	 * @throws DayException       If there's an error related to day
	 * @throws RideException      If there's an error related to ride
	 * @throws BlablakidException If the kid does not exist
	 */
	public void removeActivity(String activity, int day, String kidName)
			throws ActivityException, KidException, ParentException, DayException, RideException, BlablakidException {

		Kid kid = kidos.search(kidName);
		if (kidos.exist(kid) == false) {
			logger.error("Tried to remove " + kidName + " but didn't exist");
			throw new BlablakidException("ERROR: Kid does not exist");
		} else {
			for (int j = 0; j < kid.getNumOfActivities(); j++) {

				Ride after = kid.getActivity(j).getAfter();
				Ride before = kid.getActivity(j).getBefore();

				boolean searchingAfter = true;
				if (after == null) {
					searchingAfter = false;
				}
				boolean searchingBefore = true;
				if (before == null) {
					searchingBefore = false;
				}
				int i = 0;

				while ((searchingAfter || searchingBefore) && i < this.parentos.getNumberOfParents()) {
					Parent parent = this.parentos.get(i);
					int k = 0;

					while ((searchingAfter || searchingBefore) && k < 5) {

						if (searchingAfter
								&& parent.searchRide(after.getStartPoint(), after.getEndPoint(), k) != null) {
							parent.removeRide(after.getStartPoint(), after.getEndPoint(),
									WeekDays.values()[k].toString());
							searchingAfter = false;
						}

						if (searchingBefore
								&& parent.searchRide(before.getStartPoint(), before.getEndPoint(), k) != null) {
							parent.removeRide(before.getStartPoint(), before.getEndPoint(),
									WeekDays.values()[k].toString());
							searchingBefore = false;
						}
						k++;
					}
					i++;
				}
			}

			kid.removeActivity(activity, day);
		}
	}

	/**
	 * Method that removes a ride from everywhere
	 * 
	 * @param parentName Name of the parent
	 * @param nday       Number of the day of the activity of the ride
	 * @param startPoint Start point of the ride
	 * @param endPoint   End point of the ride
	 * @throws RideException   If there's an error related to ride
	 * @throws ParentException If there's an error related to parent
	 * @throws DayException    If there's an error related to day
	 */
	public void removeRide(String parentName, int nday, String startPoint, String endPoint)
			throws RideException, ParentException, DayException {
		Parent parent = parentos.search(parentName);
		if (parentos.search(parentName) == null) {
			throw new ParentException("ERROR: the kid " + parentName + " does not exist");
		}
		Ride ride = parent.searchRide(startPoint, endPoint, nday);
		parent.removeRide(startPoint, endPoint, WeekDays.values()[nday].toString());

		boolean searching = true;
		int i = 0;

		while (searching && i < this.kidos.getNumberOfKids()) {
			searching = this.kidos.get(i).removeRide(ride);
			i++;
		}

	}

	/**
	 * Method that shows the summary
	 * 
	 * @return Summary as a string
	 */
	public String showSummary() {

		StringBuilder output = new StringBuilder();
		output.append("///////////////////////\n\n");
		output.append("KIDS:\n\n");
		output.append(this.kidos.toString());
		output.append("PARENTS:\n");
		output.append(this.parentos.toString());
		output.append("\n///////////////////////");
		return output.toString();
	}

	/**
	 * Check the status of the rides
	 * 
	 * @return The status
	 * @throws KidException       If there's an error related to kid
	 * @throws BlablakidException If the list is empty
	 */
	public String checkStatus() throws KidException, BlablakidException {

		StringBuffer status = new StringBuffer();
		for (int i = 0; i < kidos.getNumberOfKids(); i++) {
			for (int j = 0; j < kidos.get(i).getNumOfActivities(); j++) {
				status.append(kidos.get(i).getActivity(j).checkStatus());
			}
		}
		if (status.length() == 0) {
			if (kidos.get(0) == null) {
				throw new BlablakidException("ERROR: No kids with activities in the list");
			}
			status.append("Kids have not activities without rides");
		}
		return status.toString();
	}
}

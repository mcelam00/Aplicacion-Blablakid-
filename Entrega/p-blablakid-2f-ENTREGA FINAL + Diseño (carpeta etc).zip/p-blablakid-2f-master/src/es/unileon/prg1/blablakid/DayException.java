package es.unileon.prg1.blablakid;

/**
 * Clase encargada de la gestion de excepciones en Day
 *
 * @author Roberto Viejo Lopez
 * @version 0.9
 */


public class DayException extends Exception {
	
	public DayException(String message){
		super(message);
	}

}


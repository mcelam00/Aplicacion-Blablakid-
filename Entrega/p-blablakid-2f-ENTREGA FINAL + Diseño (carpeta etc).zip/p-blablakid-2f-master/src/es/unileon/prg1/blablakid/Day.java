package es.unileon.prg1.blablakid;

/**
 * Class that represents a day
 *
 * @author Roberto Viejo Lopez
 * @version 0.9
 */
public class Day {

	/**
	 * Attribute that represent this day
	 */
	private WeekDays day;
	/**
	 * Attribute that has the rides of this day
	 */
	private Rides kRides;
	/**
	 * Constant of the min day
	 */
	final int MIN_DAY = 0;
	/**
	 * Constant of the max day
	 */
	final int MAX_DAY = 4;

	/**
	 * Class constructor, creates a day given one day
	 * 
	 * @param day           Day number (being 0 Monday to 4 Friday)
	 * @param numberOfRides The number of the krides atribute rides
	 * @throws DayException If the day is
	 */
	public Day(int day, int numberOfRides) throws DayException {
		if (day < this.MIN_DAY || day > this.MAX_DAY) {
			throw new DayException("ERROR: Day must be between" + this.MIN_DAY + " and " + this.MAX_DAY);
		} else {
			switch (day) {
			case 0:
				this.day = WeekDays.valueOf("MONDAY");
				break;
			case 1:
				this.day = WeekDays.valueOf("TUESDAY");
				break;
			case 2:
				this.day = WeekDays.valueOf("WEDNESDAY");
				break;
			case 3:
				this.day = WeekDays.valueOf("THURSDAY");
				break;
			case 4:
				this.day = WeekDays.valueOf("FRIDAY");
				break;
			}
		}
		this.kRides = new Rides(numberOfRides);
	}

	/**
	 * Method that returns the current day
	 * 
	 * @return Number of the current day (being 0 Monday to 4 Friday)
	 */
	public int getDay() {
		return this.day.ordinal();
	}

	/**
	 * Method which return a ride
	 * 
	 * @param numRide Position of the ride
	 * @return Ride
	 */
	public Ride getRide(int numRide) {
		return this.kRides.getRide(numRide);
	}

	/**
	 * Method that returns the number of rides stored in a day
	 * 
	 * @return Number of rides
	 */
	public int getNumberOfRides() {
		return this.kRides.getNumberOfRides();
	}

	/**
	 * Method that returns the max number of rides that can be stored in a day
	 * 
	 * @return Max number of rides
	 */
	public int getMaxRides() {
		return this.kRides.getSize();
	}

	/**
	 * Method that returns the current day's name
	 * 
	 * @return Current day's name
	 */
	public String getName() {
		return this.day.toString();
	}

	/**
	 * Method that adds a ride to this day
	 * 
	 * @param ride Ride that is added
	 * @throws RideException If the ride already exist or the array is full
	 */
	public void addRide(Ride ride) throws RideException {
		this.kRides.add(ride);
	}

	/**
	 * Method that removes a ride from the list
	 * 
	 * @param startPoint Where the ride starts
	 * @param endPoint   Where the ride ends
	 * @throws RideException It it couldn't be added
	 */
	public void removeRide(String startPoint, String endPoint) throws RideException {
		this.kRides.remove(this.kRides.search(startPoint, endPoint));
	}

	/**
	 * Method that compares one day with other
	 * 
	 * @param day Day to compare
	 * @return -1 if the current day is smaller in the week that the one recived in
	 *         the parameter 0 if are both are the same day 1 if the current day is
	 *         bigger in the week that the one recived in the parameter
	 */
	public int compareTo(Day day) {
		int comparation;
		if (this.getDay() == day.getDay()) {
			comparation = 0;
		} else if (this.getDay() < day.getDay()) {
			comparation = -1;
		} else {
			comparation = 1;
		}
		return comparation;
	}

	/**
	 * Method that compares one day with other
	 * 
	 * @param other Name of the other day
	 * @return -1 if the current day is smaller in the week that the one recived in
	 *         the parameter 0 if are both are the same day 1 if the current day is
	 *         bigger in the week that the one recived in the parameter
	 */
	public int compareTo(int other) {
		int comparation;
	
		if (this.getDay() == other) {
			comparation = 0;
		} else if (this.getDay() < other) {
			comparation = -1;
		} else {
			comparation = 1;
		}
		return comparation;
	}

	/**
	 * Return if a day is equal to another day
	 * 
	 * @param day Day we're comparing
	 * @return True if it's equal or false if it's not
	 */
	public boolean equalsTo(Day day) {
		boolean equals = true;
		if (this.getDay() != day.getDay()) {
			equals = false;
		}
		return equals;
	}

	/**
	 * Method that checks if a ride exists
	 * 
	 * @param ride Ride we're looking for
	 * @return True if it exist or false if it doesn't
	 */
	public boolean exist(Ride ride) {
		return this.kRides.exist(ride);
	}

	/**
	 * Method that search a ride
	 * 
	 * @param start Where the ride start
	 * @param end   Where the ride ends
	 * @return The ride you're looking for or null if it does not exist
	 * @throws RideException If it couldn't be searched
	 */
	public Ride searchRide(String start, String end) throws RideException {
		return this.kRides.search(start, end);
	}

	/**
	 * Method that returns the current day's name and its rides
	 * 
	 * @return Current day's name and its rides
	 */
	@Override
	public String toString() {
		StringBuilder output = new StringBuilder();
		if (this.getNumberOfRides() > 0) {
			output.append(this.day.toString() + "\n");
			output.append(this.kRides.toString());
		}
		return output.toString();
	}
}

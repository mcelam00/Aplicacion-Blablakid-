package es.unileon.prg1.blablakid;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;

/**
 * Class that represents an Activity
 * 
 * @author Angel Gonzalez Gonzalez
 * @version 0.9
 * 
 */
public class Activity {

	/**
	 * Attribute of logs
	 */
	private static final Logger logger = LogManager.getLogger(Activity.class);

	/**
	 * Name of the Activity
	 * 
	 * @see String
	 */
	private String name;

	/**
	 * 
	 * Place of the Activity
	 * 
	 */
	private String place;

	/**
	 * 
	 * Receives of Time when the Activity start
	 * 
	 */
	private Time start;

	/**
	 * 
	 * Receives of Time when the Activity end
	 * 
	 */
	private Time end;

	/**
	 * 
	 * Receive the day of the Activity
	 * 
	 */
	private WeekDays day;

	/**
	 * 
	 * The ride before the Activity
	 * 
	 */
	private Ride before;

	/**
	 * 
	 * The ride after the Activity
	 * 
	 */
	private Ride after;

	/**
	 * Class constructor, it creates an Activity, Place, day and an hour with the
	 * given information
	 * 
	 * @param name  Name of the activity
	 * @param place Name of where the activity takes place
	 * @param day   Day when the activity is done
	 * @throws ActivityException If there's an error
	 */
	public Activity(String name, String place, int day) throws ActivityException {

		logger.info("Tried to create an activity with name: " + name + " place: " + place + " and day: " + day);
		this.setName(name);
		this.setPlace(place);
		this.start = null;
		this.end = null;
		this.setDay(day);
		logger.info("And was created successfully");

		this.before = null;
		this.after = null;

	}

	/**
	 * 
	 * Method that return the name
	 * 
	 * @return name of the Activity
	 */
	public String getName() {

		return this.name;
	}

	/**
	 * 
	 * This method that set day if is valid
	 * 
	 * @param day Activity's day
	 * @throws ActivityException If the day is not valid it throws exception
	 */
	private void setDay(int day) throws ActivityException {

		if (day < 0 || day > 4) {
			logger.error("but the day called" + day + " was not valid");
			throw new ActivityException("ERROR: The day is invalid introduce only a number betwen 0 and 4");
		} else {
			this.day = WeekDays.values()[day];
		}

	}

	/**
	 * 
	 * Method that return the name of the place where is the Activity
	 * 
	 * @return place of the Activity
	 * 
	 */
	public String getPlace() {

		return this.place;
	}

	/**
	 * Method that return when the Activity start
	 * 
	 * @return Start of the Activity
	 */
	public Time getStart() {

		return this.start;
	}

	/**
	 * 
	 * Method that return when the Activity end
	 * 
	 * @return End of the Activity
	 */
	public Time getEnd() {

		return this.end;

	}

	/**
	 * Method that return the day of the Activity
	 * 
	 * @return Activity's day
	 */
	public WeekDays getDay() {

		return this.day;

	}

	/**
	 * Method that returns the day of the activity as an integer
	 * 
	 * @return day of the activity as an integer
	 */
	public int getDayOrdinal() {
		return this.day.ordinal();
	}

	/**
	 * Method that returns the before ride
	 * 
	 * @return before ride
	 */
	public Ride getBefore() {
		return this.before;
	}

	/**
	 * Method that returns the after ride
	 * 
	 * @return after ride
	 */
	public Ride getAfter() {
		return this.after;
	}

	/**
	 * Method that sets the name if it is valid
	 *
	 * @param name Activity's name
	 * @throws ActivityException If the name is not valid it throws exception
	 */
	private void setName(String name) throws ActivityException {

		boolean valid = this.checkName(name);

		if (!valid) {
			logger.error("but the name called " + name + " was not valid");
			throw new ActivityException("ERROR: activity is invalid, introduce only letters");
		} else {
			this.name = name;
		}
	}

	/**
	 * 
	 * Method that sets the place if it is valid
	 * 
	 * @param place Where is the Activity
	 * @throws ActivityException If the place is not valid it throws exception
	 */
	private void setPlace(String place) throws ActivityException {

		boolean valid = this.checkPlace(place);

		if (!valid) {
			logger.error("but the place calles" + place + " was not valid");
			throw new ActivityException("ERROR: place is invalid, introduce only letters and numbers without spaces");
		} else {
			this.place = place;
		}
	}

	/**
	 * Method that sets the time
	 * 
	 * @param startTime Start time
	 * @param endTime   End time
	 * @throws TimeException If the time is not valid
	 */
	public void setTime(Time startTime, Time endTime) throws TimeException {
		if (startTime.compareTo(endTime) > 0) {
			logger.error("but the time " + startTime + " was bigger than " + endTime + " not valid");
			throw new TimeException("ERROR: Invalid times, start time should be before end time");
		} else {
			this.start = startTime;
			this.end = endTime;
		}
	}

	/**
	 * Method that adds a ride to the list
	 * 
	 * @param ride Ride to be added
	 * @throws ActivityException If ride is null or already exists
	 * @return true if it has been added or false if it has not been added
	 */
	public boolean addRide(Ride ride) throws ActivityException {
		boolean added = false;
		if (this.start.compareTo(ride.getEndTime()) >= 0) {
			if (this.before != null) {
				logger.error("The ride called " + before + "already exist");
				throw new ActivityException("The ride before already exist");
			} else {
				if (this.place.compareTo(ride.getEndPoint()) == 0) {
					this.before = ride;
					added = true;
				}
			}
		} else if (this.end.compareTo(ride.getStartTime()) <= 0) {
			if (this.after != null) {
				logger.error("The ride calles " + end + "already exist");
				throw new ActivityException("The ride end already exist");
			} else {
				if (this.place.compareTo(ride.getStartPoint()) == 0) {
					this.after = ride;
					added = true;
				}
			}
		} else {
			logger.error("The ride called" + ride + "not match with the time of the activity");
			throw new ActivityException("The ride not match with the time of the activity");
		}
		return added;
	}

	/**
	 * Method that removes after or before
	 * 
	 * @param ride ride to be removed
	 * @return true if it has not been removed or false if it has been
	 */
	public boolean removeRide(Ride ride) {
		boolean searching = true;
		if (ride.equals(this.before)) {
			this.before = null;
			searching = false;
		}
		if (ride.equals(this.after)) {
			this.after = null;
			searching = false;
		}

		return searching;
	}

	/**
	 * Method that checks a name and tells if it is valid
	 * 
	 * @param name Activity's name
	 * @return True if it is valid or false if it is not valid
	 */
	private boolean checkName(String name) {

		boolean valid = true;
		String validChar = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

		if (name.length() == 0) {

			valid = false;
		}
		int counter = 0;

		while (valid && counter < name.length()) {

			if ((validChar.contains((String.valueOf(name.charAt(counter)).toUpperCase()))) == false) {

				valid = false;
			}
			counter++;
		}

		return valid;
	}

	/**
	 * 
	 * Method that checks a place and tells if it is valid or not
	 * 
	 * @param place Where is the Activity
	 * @return True if it is valid or false if it is not valid
	 */
	private boolean checkPlace(String place) {
		boolean valid = true;
		String validChar = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 ";

		if (place.length() == 0) {

			valid = false;
		}
		int counter = 0;

		while (valid && counter < place.length()) {

			if ((validChar.contains((String.valueOf(place.charAt(counter)).toUpperCase()))) == false) {

				valid = false;
			}
			counter++;
		}

		return valid;
	}

	/**
	 * Method that checks the status of the activity
	 * 
	 * @return the status as a String
	 */
	public String checkStatus() {
		StringBuffer status = new StringBuffer();

		if (this.before == null) {
			status.append("No ride before " + this.name + " assigned\n");
		} else {
			status.append(this.before.toString() + "\n");
		}
		if (this.after == null) {
			status.append("No ride after " + this.name + " assigned\n");
		} else {
			status.append(this.after.toString() + "\n");
		}

		return status.toString();
	}

	/**
	 * Method that returns an Activity as a String
	 * 
	 * @return activity as a string
	 */
	@Override
	public String toString() {
		StringBuilder output = new StringBuilder();

		output.append(this.name + "(" + this.place + " - " + this.day.toString() + "): " + this.start + " > " + this.end
				+ "\n");
		output.append(this.checkStatus());
		return output.toString();
	}

}
